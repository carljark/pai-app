# Mapa intermodular individual — 0156. Anglès professional

## Versió per mòdul amb activitats pràctiques desenvolupades

Aquest document se centra exclusivament en el mòdul **0156. Anglès professional**. Tots els seus criteris d’avaluació tenen, com a mínim, una activitat pràctica combinada amb altres mòduls de primer curs. Per augmentar la utilitat a Plappin, cada CE genera **4 activitats desenvolupades**, no enunciats genèrics.

**Criteri organitzatiu:** només es combinen mòduls de primer curs. Cada activitat vincula el CE propi amb tres CE externs d’altres mòduls, mitjançant una situació pràctica de saló, metodologia activa, producte/evidència, avaluació i DUA.

## Mòduls de primer curs considerats

- **0842. Pentinats i recollits**
- **0845. Tècniques de tall de cabells**
- **0844. Cosmètica per a perruqueria**
- **0846. Canvis de forma permanent del cabell**
- **0849. Anàlisi capil·lar**
- **1664. Digitalització aplicada als sectors productius**
- **1709. Itinerari personal per a l’ocupabilitat I**
- **0156. Anglès professional**

---

## Matriu de cobertura de criteris

| CE del mòdul eix | Activitats associades | Mòduls externs emprats |
|---|---|---|
| **0156-1a**. Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales. | 1, 2, 3, 4 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1b**. Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos. | 5, 6, 7, 8 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1c**. Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo. | 9, 10, 11, 12 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1d**. Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica. | 13, 14, 15, 16 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1e**. Seqüencia els elementos constituyentes del missatge. | 17, 18, 19, 20 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1f**. Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard. | 21, 22, 23, 24 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1g**. Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal. | 25, 26, 27, 28 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1h**. Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo. | 29, 30, 31, 32 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-1i**. Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor. | 33, 34, 35, 36 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2a**. Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto. | 37, 38, 39, 40 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2b**. Llegeix de forma comprensiva textos claros en lengua estàndard. | 41, 42, 43, 44 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2c**. Relaciona el texto amb el ámbito del sector a que se refiere. | 45, 46, 47, 48 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2d**. Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto. | 49, 50, 51, 52 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2e**. Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva. | 53, 54, 55, 56 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2f**. Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario. | 57, 58, 59, 60 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2g**. Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte. | 61, 62, 63, 64 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2h**. Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional. | 65, 66, 67, 68 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-2i**. Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes. | 69, 70, 71, 72 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3a**. Determina els registros más adequats per a la emisión del missatge. | 73, 74, 75, 76 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3b**. Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació. | 77, 78, 79, 80 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3c**. Descriu hechos breves e imprevistos relacionados amb su profesión. | 81, 82, 83, 84 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3d**. Utilitza correctamente la terminología de la profesión. | 85, 86, 87, 88 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3e**. Expressa sentimientos, ideas u opiniones. | 89, 90, 91, 92 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3f**. Enumera les actividades propias de la tarea professional. | 93, 94, 95, 96 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3g**. Descriu i secuenciado un procés de treball de su competencia. | 97, 98, 99, 100 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3h**. Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados. | 101, 102, 103, 104 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3i**. Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos. | 105, 106, 107, 108 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3j**. Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats. | 109, 110, 111, 112 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3k**. Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias. | 113, 114, 115, 116 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3l**. Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball. | 117, 118, 119, 120 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-3m**. Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión. | 121, 122, 123, 124 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4a**. Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros). | 125, 126, 127, 128 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4b**. Redacta textos breves relacionados amb aspectos cotidianos y/o professionals. | 129, 130, 131, 132 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4c**. Organitza la informació de manera coherente i cohesionada. | 133, 134, 135, 136 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4d**. Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos. | 137, 138, 139, 140 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4e**. Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico. | 141, 142, 143, 144 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4f**. Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas. | 145, 146, 147, 148 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4g**. Utilitza les fórmulas de tallsía propias del documento que se va a elaborar. | 149, 150, 151, 152 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4h**. Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual. | 153, 154, 155, 156 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4i**. Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional. | 157, 158, 159, 160 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-4j**. Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros). | 161, 162, 163, 164 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-5a**. Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera. | 165, 166, 167, 168 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-5b**. Descriu els protocolos i normas de relación social propios del país. | 169, 170, 171, 172 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-5c**. Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera. | 173, 174, 175, 176 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-5d**. Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto. | 177, 178, 179, 180 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |
| **0156-5e**. Aplica els protocolos i normas de relación social propios del país de la lengua extranjera. | 181, 182, 183, 184 | 0842, 0844, 0845, 0846, 0849, 1664, 1709 |

---

## Activitats pràctiques desenvolupades

### CE 1. 0156-1a — Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 1. Repte pràctic de diagnòstic i decisió: 0156-1a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1a · Anglès professional:** Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales.
- **CE externs combinats:**
  - **0845-1d · Tècniques de tall de cabells · RA1:** Estableix pautes d’higiene postural correcta durant el tall.
  - **0846-1e · Canvis de forma permanent del cabell · RA1:** Justifica les ventajas e inconvenientes dels métodos de realización.
  - **1664-1f · Digitalització aplicada als sectors productius · RA1:** Compara els modelos anteriores en relación amb su impacto medioambiental i els ODS (Objetivos de Desarrollo Sostenible).
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1a + 0845-1d + 0846-1e + 1664-1f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 2. Taller d’execució guiada: 0156-1a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1a · Anglès professional:** Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales.
- **CE externs combinats:**
  - **0844-1e · Cosmètica per a perruqueria · RA1:** Indica la normativa que tiene que cumplir el etiquetado.
  - **0849-1f · Anàlisi capil·lar · RA1:** Relaciona el estado del cabell amb la irrigación sanguínea.
  - **1709-2d · Itinerari personal per a l’ocupabilitat I · RA2:** Analitza els protocols d'actuació en cas d'emergència.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1a + 0844-1e + 0849-1f + 1709-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 3. Incidència professional i millora: 0156-1a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1a · Anglès professional:** Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales.
- **CE externs combinats:**
  - **0846-1f · Canvis de forma permanent del cabell · RA1:** Estableix les contraindicaciones en la aplicación.
  - **1664-2a · Digitalització aplicada als sectors productius · RA2:** Relaciona els sistemas ciber físicos amb la evolución industrial.
  - **0842-1h · Pentinats i recollits · RA1:** Identifica mètodes d’anàlisi de necessitats i demandes de les persones usuàries.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1a + 0846-1f + 1664-2a + 0842-1h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 4. Producte final per al client o portafolis: 0156-1a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1a · Anglès professional:** Situa el missatge en su contexto por medio del análisis de sus características textuales i contextuales.
- **CE externs combinats:**
  - **0849-1g · Anàlisi capil·lar · RA1:** Relaciona les características de una pell normal amb sus posibles variaciones i su repercusión capil·lar.
  - **1709-2e · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els drets i deures principals en matèria de prevenció de riscos laborals.
  - **0845-2b · Tècniques de tall de cabells · RA2:** Caracteritza les tècniques de tall recte, desfilat, dentat, entresacat i puntejat.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1a + 0849-1g + 1709-2e + 0845-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 2. 0156-1b — Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 5. Repte pràctic de diagnòstic i decisió: 0156-1b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1b · Anglès professional:** Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos.
- **CE externs combinats:**
  - **0844-2a · Cosmètica per a perruqueria · RA2:** Identifica el material i els equips de laboratorio empleados en la preparación de productos cosmètics.
  - **0849-1h · Anàlisi capil·lar · RA1:** Caracteritza les alteraciones del cabell i su importancia en perruqueria.
  - **1709-2f · Itinerari personal per a l’ocupabilitat I · RA2:** Classifica les diferents formes de gestió de la prevenció a l'empresa o organisme equiparat, en funció dels diferents criteris establerts a la normativa sobre prevenció de riscos laborals i s’han determinat les formes de representació de les persones treballadores a l'empresa o organisme equiparat en matèria de prevenció de riscs.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1b + 0844-2a + 0849-1h + 1709-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 6. Taller d’execució guiada: 0156-1b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1b · Anglès professional:** Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos.
- **CE externs combinats:**
  - **0846-2b · Canvis de forma permanent del cabell · RA2:** Especifica les características físicas i químicas del cabell amb repercusión en estas tècniques.
  - **1664-2c · Digitalització aplicada als sectors productius · RA2:** Descriu la combinación de la parte física de les industrias amb el software, IoT (Internet de les cosas), comunicaciones, entre otros.
  - **0842-2a · Pentinats i recollits · RA2:** Selecciona els aparells generadors de calor en funció del procés.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1b + 0846-2b + 1664-2c + 0842-2a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 7. Incidència professional i millora: 0156-1b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1b · Anglès professional:** Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos.
- **CE externs combinats:**
  - **0849-1i · Anàlisi capil·lar · RA1:** Especifica els efectos del sol en la pell i el cabell.
  - **1709-2g · Itinerari personal per a l’ocupabilitat I · RA2:** Valora la importància de l'existència d'un pla preventiu a l'empresa o organisme equiparat que inclogui la seqüenciació d'actuacions que cal realitzar en cas d'emergència i s’ha reflexionat sobre el seu contingut.
  - **0845-2d · Tècniques de tall de cabells · RA2:** Estableix les línies de tall adequades per a cada tècnica.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1b + 0849-1i + 1709-2g + 0845-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 8. Producte final per al client o portafolis: 0156-1b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1b · Anglès professional:** Identifica el hilo argumental de missatges orales i determinado els roles que aparecen en els mismos.
- **CE externs combinats:**
  - **1664-2d · Digitalització aplicada als sectors productius · RA2:** Descriu la interrelación entre el mundo físico i el virtual.
  - **0842-2b · Pentinats i recollits · RA2:** Caracteritza els útils i les eines emprats.
  - **0844-2f · Cosmètica per a perruqueria · RA2:** Determina les pautas delaboración en función del tipo de cosmètic que se va a preparar.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1b + 1664-2d + 0842-2b + 0844-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 3. 0156-1c — Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 9. Repte pràctic de diagnòstic i decisió: 0156-1c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1c · Anglès professional:** Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo.
- **CE externs combinats:**
  - **0846-2d · Canvis de forma permanent del cabell · RA2:** Identifica les alteraciones del cuero cabelludo i del cabell.
  - **1664-2e · Digitalització aplicada als sectors productius · RA2:** Relaciona la migración a entornos 4.0 amb la mejora dels resultats de les empresas.
  - **0842-2c · Pentinats i recollits · RA2:** Selecciona els motlles en funció de l’efecte desitjat.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1c + 0846-2d + 1664-2e + 0842-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 10. Taller d’execució guiada: 0156-1c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1c · Anglès professional:** Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo.
- **CE externs combinats:**
  - **0849-2a · Anàlisi capil·lar · RA2:** Identifica els aparells usados en el análisis.
  - **1709-2i · Itinerari personal per a l’ocupabilitat I · RA2:** Identifica les tècniques bàsiques de primers auxilis que han de ser aplicades al lloc de l'accident en cas de diferents tipus de danys i la composició i ús de la farmaciola.
  - **0845-2f · Tècniques de tall de cabells · RA2:** Determina les zones d’aplicació de cada tècnica de tall.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1c + 0849-2a + 1709-2i + 0845-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 11. Incidència professional i millora: 0156-1c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1c · Anglès professional:** Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo.
- **CE externs combinats:**
  - **1664-2f · Digitalització aplicada als sectors productius · RA2:** Identifica les ventajas per a clients i empresas.
  - **0842-2d · Pentinats i recollits · RA2:** Estableix pautes de manteniment d’aparells, útils i complements.
  - **0844-2h · Cosmètica per a perruqueria · RA2:** Segueix les pautas de limpieza i colocación del material de laboratorio empleado.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1c + 1664-2f + 0842-2d + 0844-2h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 12. Producte final per al client o portafolis: 0156-1c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1c · Anglès professional:** Reconeix la finalidad del missatge, ya se trate de un missatge directo, telefónico o en cualquier otro medio auditivo.
- **CE externs combinats:**
  - **1709-3a · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza els drets i les obligacions derivats de la relació laboral, així com les condicions de treball pactades en un conveni col·lectiu aplicable en el sector professional relacionat amb el títol.
  - **0845-2g · Tècniques de tall de cabells · RA2:** Selecciona procediments per realitzar tècniques de desfilat, dentat, entresacat i puntejat.
  - **0846-3b · Canvis de forma permanent del cabell · RA3:** Aplica les medidas de protecció i seguretat del professional i el usuari.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1c + 1709-3a + 0845-2g + 0846-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 4. 0156-1d — Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 13. Repte pràctic de diagnòstic i decisió: 0156-1d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1d · Anglès professional:** Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica.
- **CE externs combinats:**
  - **0849-2c · Anàlisi capil·lar · RA2:** Relaciona el fundamento científico de cada uno dellos, amb sus indicaciones i contraindicaciones.
  - **1709-3b · Itinerari personal per a l’ocupabilitat I · RA3:** Compara les principals modalitats de contractació i s’han localitzat els diferents models a les fonts oficials.
  - **0845-2h · Tècniques de tall de cabells · RA2:** Relaciona els paràmetres que defineixen cada tècnica amb els efectes aconseguits.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1d + 0849-2c + 1709-3b + 0845-2h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 14. Taller d’execució guiada: 0156-1d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1d · Anglès professional:** Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica.
- **CE externs combinats:**
  - **1664-3b · Digitalització aplicada als sectors productius · RA3:** Identifica les principales funciones de la cloud /nube (procesamiento de dades, intercambio de informació, ejecución de aplicaciones, entre otros).
  - **0842-2f · Pentinats i recollits · RA2:** Estableix criteris de selecció dels cosmètics.
  - **0844-3b · Cosmètica per a perruqueria · RA3:** Relaciona el mecanismo de acción de un champú amb els ingredientes activos que contiene.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1d + 1664-3b + 0842-2f + 0844-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 15. Incidència professional i millora: 0156-1d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1d · Anglès professional:** Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica.
- **CE externs combinats:**
  - **1709-3c · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica les característiques definitòries dels nous entorns d'organització del treball i els drets que comporta, així com les mesures vigents per a la conciliació de la vida laboral i familiar.
  - **0845-3a · Tècniques de tall de cabells · RA3:** Identifica les característiques i alteracions del cabell que influeixen en el tall.
  - **0846-3d · Canvis de forma permanent del cabell · RA3:** Caracteritza els útils i eines necessaris per a el procés.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1d + 1709-3c + 0845-3a + 0846-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 16. Producte final per al client o portafolis: 0156-1d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1d · Anglès professional:** Extreu informació específica contenida en discursos orales, en lengua estàndard, relacionados amb la vida social, professional o académica.
- **CE externs combinats:**
  - **0842-2g · Pentinats i recollits · RA2:** Segueix pautes de neteja dels útils després de l’ús.
  - **0844-3c · Cosmètica per a perruqueria · RA3:** Relaciona la composición de un acondicionador amb els efectos que origina en la fibra capil·lar.
  - **0849-3b · Anàlisi capil·lar · RA3:** Identifica els dades que permiten obtener informació útil per a el análisis capil·lar.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1d + 0842-2g + 0844-3c + 0849-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 5. 0156-1e — Seqüencia els elementos constituyentes del missatge.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 17. Repte pràctic de diagnòstic i decisió: 0156-1e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1e · Anglès professional:** Seqüencia els elementos constituyentes del missatge.
- **CE externs combinats:**
  - **1664-3d · Digitalització aplicada als sectors productius · RA3:** Defineix els conceptos de fog i mist i sus zonas de aplicación en el conjunto.
  - **0842-2h · Pentinats i recollits · RA2:** Col·loca els mitjans necessaris al tocador i a l’àrea de treball.
  - **0844-3d · Cosmètica per a perruqueria · RA3:** Determina els efectos dels protectores sobre la fibra capil·lar.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1e + 1664-3d + 0842-2h + 0844-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 18. Taller d’execució guiada: 0156-1e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1e · Anglès professional:** Seqüencia els elementos constituyentes del missatge.
- **CE externs combinats:**
  - **1709-3e · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els recursos laborals existents en les diferents vicissituds que es poden generar en la relació laboral.
  - **0845-3c · Tècniques de tall de cabells · RA3:** Relaciona les proporcions facials i corporals amb el canvi de longitud del cabell.
  - **0846-3f · Canvis de forma permanent del cabell · RA3:** Selecciona els moldes en función de les características del cabell i el resultat deseado.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1e + 1709-3e + 0845-3c + 0846-3f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 19. Incidència professional i millora: 0156-1e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1e · Anglès professional:** Seqüencia els elementos constituyentes del missatge.
- **CE externs combinats:**
  - **0842-3a · Pentinats i recollits · RA3:** Identifica els requisits del rentacaps i de la butaca.
  - **0844-3e · Cosmètica per a perruqueria · RA3:** Estableix les transformaciones que tienen lugar en la fibra capil·lar en els processos de cambio de forma temporal del cabell.
  - **0849-3d · Anàlisi capil·lar · RA3:** Maneja la lupa i la luz de wood per a la observación del estado del cabell i cuero cabelludo.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1e + 0842-3a + 0844-3e + 0849-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 20. Producte final per al client o portafolis: 0156-1e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1e · Anglès professional:** Seqüencia els elementos constituyentes del missatge.
- **CE externs combinats:**
  - **0845-3d · Tècniques de tall de cabells · RA3:** Selecciona imatges i fotografies de pentinats segons l’estil de tall proposat.
  - **0846-3g · Canvis de forma permanent del cabell · RA3:** Selecciona els cosmètics adequat per a els cambios de forma permanent.
  - **1664-4d · Digitalització aplicada als sectors productius · RA4:** Relaciona la alineación entre les unidades funcionales de les empresas que conforman el sistema i el objetivo del mismo.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1e + 0845-3d + 0846-3g + 1664-4d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 6. 0156-1f — Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 21. Repte pràctic de diagnòstic i decisió: 0156-1f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1f · Anglès professional:** Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard.
- **CE externs combinats:**
  - **1709-3g · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza les principals prestacions derivades de la suspensió i l'extinció de la relació laboral.
  - **0845-3e · Tècniques de tall de cabells · RA3:** Identifica els elements d’un esbós de proposta de tall.
  - **0846-3h · Canvis de forma permanent del cabell · RA3:** Manipula i conservado els productos químicos i cosmètics en condiciones de seguretat e higiene.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1f + 1709-3g + 0845-3e + 0846-3h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 22. Taller d’execució guiada: 0156-1f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1f · Anglès professional:** Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard.
- **CE externs combinats:**
  - **0842-3c · Pentinats i recollits · RA3:** Segueix pautes de manipulació dels cosmètics.
  - **0844-3g · Cosmètica per a perruqueria · RA3:** Identifica els componentes dels cosmètics per a cambios de color i su acción sobre el tallo capil·lar.
  - **0849-3f · Anàlisi capil·lar · RA3:** Comprova la posible existencia de alteraciones.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1f + 0842-3c + 0844-3g + 0849-3f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 23. Incidència professional i millora: 0156-1f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1f · Anglès professional:** Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard.
- **CE externs combinats:**
  - **0845-3f · Tècniques de tall de cabells · RA3:** Realitza esbossos gràfics per a la proposta de tall.
  - **0846-4a · Canvis de forma permanent del cabell · RA4:** Comprova el estado del cabell.
  - **1664-4f · Digitalització aplicada als sectors productius · RA4:** Relaciona les tecnologías disruptivas amb aplicaciones concretas en els sectores productivos.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1f + 0845-3f + 0846-4a + 1664-4f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 24. Producte final per al client o portafolis: 0156-1f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1f · Anglès professional:** Identifica i resumido amb claridad les ideas principales de un discurso sobre temas conocidos, transmitido por els medios de comunicació i emitido en lengua estàndard.
- **CE externs combinats:**
  - **0844-3h · Cosmètica per a perruqueria · RA3:** Reconeix els cosmètics per a les alteraciones capil·lares que se emplean habitualmente en establecimientos de perruqueria.
  - **0849-3g · Anàlisi capil·lar · RA3:** Realitza la recogida de informació.
  - **1709-4c · Itinerari personal per a l’ocupabilitat I · RA4:** Determina les competències personals i socials amb valor per a l'ocupació.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1f + 0844-3h + 0849-3g + 1709-4c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 7. 0156-1g — Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 25. Repte pràctic de diagnòstic i decisió: 0156-1g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1g · Anglès professional:** Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal.
- **CE externs combinats:**
  - **0842-3e · Pentinats i recollits · RA3:** Estableix les fases i pautes d’aplicació.
  - **0844-3i · Cosmètica per a perruqueria · RA3:** Valora la importancia de la elección del cosmètic adequat en cada procés técnico.
  - **0849-3h · Anàlisi capil·lar · RA3:** Relaciona els dades obtenidos amb su posible derivación a otros professionals.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1g + 0842-3e + 0844-3i + 0849-3h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 26. Taller d’execució guiada: 0156-1g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1g · Anglès professional:** Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal.
- **CE externs combinats:**
  - **0845-4a · Tècniques de tall de cabells · RA4:** Estableix pautes per al maneig i la subjecció de la tisora.
  - **0846-4c · Canvis de forma permanent del cabell · RA4:** Realitza la repartición zonal del cabell en función del montaje.
  - **1664-4h · Digitalització aplicada als sectors productius · RA4:** Descriu les mejoras producidas en el sistema i en cada una de sus etapas.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1g + 0845-4a + 0846-4c + 1664-4h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 27. Incidència professional i millora: 0156-1g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1g · Anglès professional:** Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal.
- **CE externs combinats:**
  - **0844-4a · Cosmètica per a perruqueria · RA4:** Identifica els cosmètics per a manicura i pedicura.
  - **0849-4a · Anàlisi capil·lar · RA4:** Caracteritza les fases de un protocolo.
  - **1709-4e · Itinerari personal per a l’ocupabilitat I · RA4:** Valora el concepte d'autoestima en el procés de cerca de feina.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1g + 0844-4a + 0849-4a + 1709-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 28. Producte final per al client o portafolis: 0156-1g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1g · Anglès professional:** Reconeix les instrucciones orales i s’han seguido les indicaciones siendo capaz de concluir si precisan de una respuesta verbal o de una no verbal.
- **CE externs combinats:**
  - **0846-4d · Canvis de forma permanent del cabell · RA4:** Realitza el enrollado del cabell sobre els bigudíes segons la secuencia establecida.
  - **1664-5a · Digitalització aplicada als sectors productius · RA5:** Defineix a nivel de bloques el diagrama de funcionamiento de la empresa clásica.
  - **0842-4a · Pentinats i recollits · RA4:** Determina les operacions prèvies i les particions del cabell en funció del pentinat.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1g + 0846-4d + 1664-5a + 0842-4a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 8. 0156-1h — Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 29. Repte pràctic de diagnòstic i decisió: 0156-1h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1h · Anglès professional:** Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo.
- **CE externs combinats:**
  - **0845-4c · Tècniques de tall de cabells · RA4:** Efectua les tècniques prèvies de condicionament del cabell.
  - **0846-4e · Canvis de forma permanent del cabell · RA4:** Verifica el montaje de bigudíes.
  - **1664-5b · Digitalització aplicada als sectors productius · RA5:** Identifica les etapas susceptibles de ser digitalizadas.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1h + 0845-4c + 0846-4e + 1664-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 30. Taller d’execució guiada: 0156-1h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1h · Anglès professional:** Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo.
- **CE externs combinats:**
  - **0844-4c · Cosmètica per a perruqueria · RA4:** Relaciona la forma cosmética amb el modo de aplicación.
  - **0849-4c · Anàlisi capil·lar · RA4:** Elabora protocolos per a el mantenimiento de cabells teñidos, decolorados i permanentados.
  - **1709-4g · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica expectatives de futur per a la inserció professional i s’han analitzat competències, interessos i destreses personals.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1h + 0844-4c + 0849-4c + 1709-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 31. Incidència professional i millora: 0156-1h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1h · Anglès professional:** Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo.
- **CE externs combinats:**
  - **0846-4f · Canvis de forma permanent del cabell · RA4:** Aplica els líquidos reductores en la fase de saturación.
  - **1664-5c · Digitalització aplicada als sectors productius · RA5:** Defineix les tecnologías implicadas en cada una de les etapas.
  - **0842-4c · Pentinats i recollits · RA4:** Selecciona els paràmetres dels aparells generadors de calor.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1h + 0846-4f + 1664-5c + 0842-4c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 32. Producte final per al client o portafolis: 0156-1h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1h · Anglès professional:** Pren conciencia de la importancia de comprènr globalmente un missatge, sin necesidad de entender todos i cada uno dels elementos del mismo.
- **CE externs combinats:**
  - **0849-4d · Anàlisi capil·lar · RA4:** Determina els medios, tècniques i materials necessaris.
  - **1709-4h · Itinerari personal per a l’ocupabilitat I · RA4:** Valora fites importants en la trajectòria vital amb valor professionalitzador.
  - **0845-4h · Tècniques de tall de cabells · RA4:** Aplica procediments establerts en la realització del tall amb tisora.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1h + 0849-4d + 1709-4h + 0845-4h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 9. 0156-1i — Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor.

**RA del mòdul eix:** 0156-RA1. Comprensió d’informació oral professional i quotidiana en llengua anglesa.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 33. Repte pràctic de diagnòstic i decisió: 0156-1i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1i · Anglès professional:** Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor.
- **CE externs combinats:**
  - **0844-4e · Cosmètica per a perruqueria · RA4:** Especifica els cosmètics empleados en el procés de afeitado en establecimientos de perruqueria.
  - **0849-4e · Anàlisi capil·lar · RA4:** Caracteritza la duración i el número de sesiones dels diferentes protocolos.
  - **1709-4i · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica els itineraris formatius professionals relacionats amb el perfil professional.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-1i + 0844-4e + 0849-4e + 1709-4i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 34. Taller d’execució guiada: 0156-1i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1i · Anglès professional:** Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor.
- **CE externs combinats:**
  - **0846-4h · Canvis de forma permanent del cabell · RA4:** Aplica el neutralizante siguiendo el procediment establecido.
  - **1664-5e · Digitalització aplicada als sectors productius · RA5:** Elabora un diagrama de bloques del sistema digitalizado.
  - **0842-4e · Pentinats i recollits · RA4:** Estableix el procediment de realització d’anelles i ones a l’aigua.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-1i + 0846-4h + 1664-5e + 0842-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 35. Incidència professional i millora: 0156-1i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1i · Anglès professional:** Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor.
- **CE externs combinats:**
  - **0849-5a · Anàlisi capil·lar · RA5:** Determina els tipos de maniobras del masaje capil·lar.
  - **1709-4j · Itinerari personal per a l’ocupabilitat I · RA4:** Formula objectius professionals i s'han determinat metes personals i professionals per millorar l'ocupabilitat i les condicions d'inserció laboral.
  - **0845-5b · Tècniques de tall de cabells · RA5:** Estableix pautes per al maneig de la navalla.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-1i + 0849-5a + 1709-4j + 0845-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 36. Producte final per al client o portafolis: 0156-1i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-1i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-1i · Anglès professional:** Se serveix del análisis de la entonación i dels elementos visuales per a identificar els diversos significados e intenciones comunicativas del emisor.
- **CE externs combinats:**
  - **1664-5f · Digitalització aplicada als sectors productius · RA5:** Elabora un informe de viabilidad i de les mejoras introducidas.
  - **0842-4f · Pentinats i recollits · RA4:** Aplica muntatges de rul·los per efectuar un marcat.
  - **0844-5b · Cosmètica per a perruqueria · RA5:** Relaciona les alteraciones en la composición dels productos cosmètics amb els cambios que se originan en sus características organolépticas.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-1i + 1664-5f + 0842-4f + 0844-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 10. 0156-2a — Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 37. Repte pràctic de diagnòstic i decisió: 0156-2a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2a · Anglès professional:** Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto.
- **CE externs combinats:**
  - **0846-4j · Canvis de forma permanent del cabell · RA4:** Aplica les normas de prevenció, seguretat i protecció ambiental estipuladas, durante el procés de treball.
  - **1664-5g · Digitalització aplicada als sectors productius · RA5:** Analitza la mejora en la producción i gestión de residuos, entre otras.
  - **0842-4g · Pentinats i recollits · RA4:** Justifica l’ús de tècniques auxiliars i associades per realitzar el pentinat.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2a + 0846-4j + 1664-5g + 0842-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 38. Taller d’execució guiada: 0156-2a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2a · Anglès professional:** Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto.
- **CE externs combinats:**
  - **0849-5c · Anàlisi capil·lar · RA5:** Aplica tècniques de masaje en els cuidados capil·lares.
  - **1709-5a · Itinerari personal per a l’ocupabilitat I · RA5:** Pren consciència de la responsabilitat individual en el desenvolupament professional per tal de valorar l'actitud d'aprenentatge permanent per al desenvolupament de competències pròpies i noves.
  - **0845-5d · Tècniques de tall de cabells · RA5:** Estableix seccions i línies per al tall amb navalla.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2a + 0849-5c + 1709-5a + 0845-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 39. Incidència professional i millora: 0156-2a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2a · Anglès professional:** Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto.
- **CE externs combinats:**
  - **1664-5h · Digitalització aplicada als sectors productius · RA5:** Elabora un documento amb la secuencia del plan de transformación i els recursos empleados.
  - **0842-4h · Pentinats i recollits · RA4:** Realitza la seqüència d’operacions del pentinat.
  - **0844-5d · Cosmètica per a perruqueria · RA5:** Especifica les pautas correctas de manipulación dels productos cosmètics per a garantizar unas condiciones higiénico-sanitarias idóneas de aplicación.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2a + 1664-5h + 0842-4h + 0844-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 40. Producte final per al client o portafolis: 0156-2a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2a · Anglès professional:** Selecciona els materials de consulta i diccionarios técnicos. per a la comprensión del texto.
- **CE externs combinats:**
  - **1709-5b · Itinerari personal per a l’ocupabilitat I · RA5:** Identifica l’ocupabilitat com a capacitat d’adaptació a l’entorn laboral.
  - **0845-5e · Tècniques de tall de cabells · RA5:** Relaciona l’angle d’inclinació de la navalla amb l’efecte pretès.
  - **0846-5e · Canvis de forma permanent del cabell · RA5:** Controla el procés durante el tiempo de exposición.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2a + 1709-5b + 0845-5e + 0846-5e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 11. 0156-2b — Llegeix de forma comprensiva textos claros en lengua estàndard.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 41. Repte pràctic de diagnòstic i decisió: 0156-2b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2b · Anglès professional:** Llegeix de forma comprensiva textos claros en lengua estàndard.
- **CE externs combinats:**
  - **0849-5e · Anàlisi capil·lar · RA5:** Estableix les recomendaciones e informaciones post-tratamiento.
  - **1709-5c · Itinerari personal per a l’ocupabilitat I · RA5:** Coneix i utilitzat eines, fonts d'informació, connexions i activitats per configurar un entorn personal d'aprenentatge per a l'ocupabilitat.
  - **0845-5f · Tècniques de tall de cabells · RA5:** Estableix la seqüència d’actuació del tall amb navalla.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2b + 0849-5e + 1709-5c + 0845-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 42. Taller d’execució guiada: 0156-2b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2b · Anglès professional:** Llegeix de forma comprensiva textos claros en lengua estàndard.
- **CE externs combinats:**
  - **1664-1b · Digitalització aplicada als sectors productius · RA1:** Analitza cada etapa dels modelos EL i EC i su repercusión en el medi ambient.
  - **0842-5a · Pentinats i recollits · RA5:** Realitza operacions prèvies relacionades amb el recollit.
  - **0844-5f · Cosmètica per a perruqueria · RA5:** Aplica les pautas de recogida dels productos cosmètics contaminados y/o alterados, respetando la normativa vigente i el medi ambient.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2b + 1664-1b + 0842-5a + 0844-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 43. Incidència professional i millora: 0156-2b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2b · Anglès professional:** Llegeix de forma comprensiva textos claros en lengua estàndard.
- **CE externs combinats:**
  - **1709-5d · Itinerari personal per a l’ocupabilitat I · RA5:** Posa en pràctica la competència digital per configurar un entorn personal d’aprenentatge per a l’ocupabilitat.
  - **0845-5g · Tècniques de tall de cabells · RA5:** Determina les precaucions que cal observar en el maneig de la navalla.
  - **0846-5g · Canvis de forma permanent del cabell · RA5:** Realitza els ajustes necessaris en el procés.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2b + 1709-5d + 0845-5g + 0846-5g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 44. Producte final per al client o portafolis: 0156-2b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2b · Anglès professional:** Llegeix de forma comprensiva textos claros en lengua estàndard.
- **CE externs combinats:**
  - **0842-5b · Pentinats i recollits · RA5:** Selecciona eines, productes i complements.
  - **0844-6a · Cosmètica per a perruqueria · RA6:** Identifica les líneas comerciales de cosmètics per a perruqueria.
  - **0849-6b · Anàlisi capil·lar · RA6:** Valora la aplicación de normas deontológicas en el desarrollo professional.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2b + 0842-5b + 0844-6a + 0849-6b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 12. 0156-2c — Relaciona el texto amb el ámbito del sector a que se refiere.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 45. Repte pràctic de diagnòstic i decisió: 0156-2c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2c · Anglès professional:** Relaciona el texto amb el ámbito del sector a que se refiere.
- **CE externs combinats:**
  - **1664-1d · Digitalització aplicada als sectors productius · RA1:** Identifica processos reales basados en EL.
  - **0842-5c · Pentinats i recollits · RA5:** Diferencia les tècniques d’execució de diferents trenats.
  - **0844-6b · Cosmètica per a perruqueria · RA6:** Estableix les diferencias entre els cosmètics de venta al público i els de uso professional.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2c + 1664-1d + 0842-5c + 0844-6b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 46. Taller d’execució guiada: 0156-2c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2c · Anglès professional:** Relaciona el texto amb el ámbito del sector a que se refiere.
- **CE externs combinats:**
  - **1709-5f · Itinerari personal per a l’ocupabilitat I · RA5:** Justifica el disseny del seu entorn d'aprenentatge basat en la millora l'ocupabilitat.
  - **0845-6a · Tècniques de tall de cabells · RA6:** Estableix pautes per al maneig de la màquina.
  - **0846-5i · Canvis de forma permanent del cabell · RA5:** Determina els cuidados posteriores al desrizado.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2c + 1709-5f + 0845-6a + 0846-5i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 47. Incidència professional i millora: 0156-2c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2c · Anglès professional:** Relaciona el texto amb el ámbito del sector a que se refiere.
- **CE externs combinats:**
  - **0842-5d · Pentinats i recollits · RA5:** Estableix el mode de realització d’enrotllats, anelles, retorçats i bucles.
  - **0844-6c · Cosmètica per a perruqueria · RA6:** Especifica els establecimientos de venta de cosmètics per a perruqueria.
  - **0849-6d · Anàlisi capil·lar · RA6:** Valora la importancia i repercusión del treball honesto.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2c + 0842-5d + 0844-6c + 0849-6d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 48. Producte final per al client o portafolis: 0156-2c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2c · Anglès professional:** Relaciona el texto amb el ámbito del sector a que se refiere.
- **CE externs combinats:**
  - **0845-6b · Tècniques de tall de cabells · RA6:** Selecciona accessoris i útils segons la longitud desitjada del cabell.
  - **0846-5j · Canvis de forma permanent del cabell · RA5:** Identifica tendencias i nuevos productos de desrizado i alisado.
  - **1664-2c · Digitalització aplicada als sectors productius · RA2:** Descriu la combinación de la parte física de les industrias amb el software, IoT (Internet de les cosas), comunicaciones, entre otros.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2c + 0845-6b + 0846-5j + 1664-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 13. 0156-2d — Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 49. Repte pràctic de diagnòstic i decisió: 0156-2d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2d · Anglès professional:** Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto.
- **CE externs combinats:**
  - **1709-5h · Itinerari personal per a l’ocupabilitat I · RA5:** Aplica les eines d'aprenentatge autònom per al desenvolupament personal i professional.
  - **0845-6c · Tècniques de tall de cabells · RA6:** Realitza el muntatge i desmuntatge de components i accessoris.
  - **0846-6a · Canvis de forma permanent del cabell · RA6:** Determina els factores que afectan al resultat.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2d + 1709-5h + 0845-6c + 0846-6a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 50. Taller d’execució guiada: 0156-2d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2d · Anglès professional:** Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto.
- **CE externs combinats:**
  - **0842-5f · Pentinats i recollits · RA5:** Adapta postissos en l’execució d’un recollit.
  - **0844-6e · Cosmètica per a perruqueria · RA6:** Relaciona el consejo professional amb la mejora del servicio de venta de cosmètics.
  - **0849-6f · Anàlisi capil·lar · RA6:** Treballa el respeto a la diferencia.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2d + 0842-5f + 0844-6e + 0849-6f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 51. Incidència professional i millora: 0156-2d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2d · Anglès professional:** Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto.
- **CE externs combinats:**
  - **0845-6d · Tècniques de tall de cabells · RA6:** Verifica l’estat de la màquina.
  - **0846-6b · Canvis de forma permanent del cabell · RA6:** Relaciona els errores más frecuentes en la realización, amb la fase en la que s’han producido.
  - **1664-2e · Digitalització aplicada als sectors productius · RA2:** Relaciona la migración a entornos 4.0 amb la mejora dels resultats de les empresas.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2d + 0845-6d + 0846-6b + 1664-2e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 52. Producte final per al client o portafolis: 0156-2d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2d · Anglès professional:** Reconeix les ideas principales de un texto escrit identificando la informació relevante, sin necesidad de entender todos i cada uno dels elementos de dicho texto.
- **CE externs combinats:**
  - **0844-6f · Cosmètica per a perruqueria · RA6:** Determina la importancia de mantener una constante actualización en productos de innovación en perruqueria.
  - **0849-6g · Anàlisi capil·lar · RA6:** Valora la repercusión de la ley de protecció de dades en el ejercicio professional de la perruqueria.
  - **1709-2a · Itinerari personal per a l’ocupabilitat I · RA2:** Valora la importància de la cultura preventiva en tots els àmbits i activitats de l'empresa o organisme equiparat, i s’han relacionat les condicions laborals amb la salut de la persona treballadora, per tal d'identificar i classificar els factors de risc en l'activitat i els danys que se'n deriven, especialment les situacions de risc més habituals en els entorns de treball del sector professional relacionat amb el títol.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2d + 0844-6f + 0849-6g + 1709-2a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 14. 0156-2e — Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 53. Repte pràctic de diagnòstic i decisió: 0156-2e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2e · Anglès professional:** Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva.
- **CE externs combinats:**
  - **0842-5h · Pentinats i recollits · RA5:** Relaciona els mètodes de subjecció del recollit amb els útils i les eines apropiats.
  - **0844-6g · Cosmètica per a perruqueria · RA6:** Utilitza medios per a obtener informació sobre innovaciones cosméticas per a perruqueria.
  - **0849-1a · Anàlisi capil·lar · RA1:** Identifica les características i elementos que componen el relieve cutani.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2e + 0842-5h + 0844-6g + 0849-1a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 54. Taller d’execució guiada: 0156-2e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2e · Anglès professional:** Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva.
- **CE externs combinats:**
  - **0845-6f · Tècniques de tall de cabells · RA6:** Estableix l’ordre de realització del tall amb màquina.
  - **0846-6d · Canvis de forma permanent del cabell · RA6:** Proposa medidas de asesoramiento al usuari per a el mantenimiento del treball técnico realizado.
  - **1664-3a · Digitalització aplicada als sectors productius · RA3:** Identifica els diferentes niveles de la cloud /nube.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2e + 0845-6f + 0846-6d + 1664-3a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 55. Incidència professional i millora: 0156-2e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2e · Anglès professional:** Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva.
- **CE externs combinats:**
  - **0844-1a · Cosmètica per a perruqueria · RA1:** Identifica les características del producto cosmètic segons la reglamentación técnico-sanitaria.
  - **0849-1b · Anàlisi capil·lar · RA1:** Caracteritza la estructura de la pell i sus glándulas.
  - **1709-2c · Itinerari personal per a l’ocupabilitat I · RA2:** Determina l'avaluació de riscos a l'empresa o organisme equiparat i s’han definit les tècniques de prevenció i de protecció que cal aplicar per evitar els danys a l'origen i minimitzar-ne les conseqüències.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2e + 0844-1a + 0849-1b + 1709-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 56. Producte final per al client o portafolis: 0156-2e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2e · Anglès professional:** Identifica la terminología utilizada, así como les estructuras gramaticales i demás elementos característicos de cada tipología discursiva.
- **CE externs combinats:**
  - **0846-6e · Canvis de forma permanent del cabell · RA6:** Adopta medidas de resolución de les desviaciones producidas en el desarrollo de la actividad.
  - **1664-3b · Digitalització aplicada als sectors productius · RA3:** Identifica les principales funciones de la cloud /nube (procesamiento de dades, intercambio de informació, ejecución de aplicaciones, entre otros).
  - **0842-6d · Pentinats i recollits · RA6:** Diferencia els tipus d’extensions segons la tècnica de fixació.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2e + 0846-6e + 1664-3b + 0842-6d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 15. 0156-2f — Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 57. Repte pràctic de diagnòstic i decisió: 0156-2f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2f · Anglès professional:** Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario.
- **CE externs combinats:**
  - **0845-6h · Tècniques de tall de cabells · RA6:** Realitza el perfilat de contorns i altres tècniques de finalització.
  - **0846-6f · Canvis de forma permanent del cabell · RA6:** Segueix el protocolo de actuación en casos de irritaciones i alergias.
  - **1664-3c · Digitalització aplicada als sectors productius · RA3:** Descriu el concepto de edge computing i su relación amb la cloud/ nube.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2f + 0845-6h + 0846-6f + 1664-3c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 58. Taller d’execució guiada: 0156-2f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2f · Anglès professional:** Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario.
- **CE externs combinats:**
  - **0844-1c · Cosmètica per a perruqueria · RA1:** Relaciona les características de les sustancias empleadas en els cosmètics, amb la función que desempeñan.
  - **0849-1d · Anàlisi capil·lar · RA1:** Justifica el carácter cíclico del crecimiento piloso.
  - **1709-2e · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els drets i deures principals en matèria de prevenció de riscos laborals.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2f + 0844-1c + 0849-1d + 1709-2e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 59. Incidència professional i millora: 0156-2f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2f · Anglès professional:** Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario.
- **CE externs combinats:**
  - **0846-1a · Canvis de forma permanent del cabell · RA1:** Identifica les fases dels cambios de forma permanent.
  - **1664-3d · Digitalització aplicada als sectors productius · RA3:** Defineix els conceptos de fog i mist i sus zonas de aplicación en el conjunto.
  - **0842-6f · Pentinats i recollits · RA6:** Retira les extensions del cabell.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2f + 0846-1a + 1664-3d + 0842-6f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 60. Producte final per al client o portafolis: 0156-2f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2f · Anglès professional:** Realitza traducciones de textos en lengua estàndard utilizando material de apoyo en caso necesario.
- **CE externs combinats:**
  - **0849-1e · Anàlisi capil·lar · RA1:** Reconeix les características i componentes del cabell.
  - **1709-2f · Itinerari personal per a l’ocupabilitat I · RA2:** Classifica les diferents formes de gestió de la prevenció a l'empresa o organisme equiparat, en funció dels diferents criteris establerts a la normativa sobre prevenció de riscos laborals i s’han determinat les formes de representació de les persones treballadores a l'empresa o organisme equiparat en matèria de prevenció de riscs.
  - **0845-7e · Tècniques de tall de cabells · RA7:** Selecciona diferents tècniques segons el resultat final.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2f + 0849-1e + 1709-2f + 0845-7e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 16. 0156-2g — Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 61. Repte pràctic de diagnòstic i decisió: 0156-2g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2g · Anglès professional:** Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte.
- **CE externs combinats:**
  - **0844-1e · Cosmètica per a perruqueria · RA1:** Indica la normativa que tiene que cumplir el etiquetado.
  - **0849-1f · Anàlisi capil·lar · RA1:** Relaciona el estado del cabell amb la irrigación sanguínea.
  - **1709-2g · Itinerari personal per a l’ocupabilitat I · RA2:** Valora la importància de l'existència d'un pla preventiu a l'empresa o organisme equiparat que inclogui la seqüenciació d'actuacions que cal realitzar en cas d'emergència i s’ha reflexionat sobre el seu contingut.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2g + 0844-1e + 0849-1f + 1709-2g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 62. Taller d’execució guiada: 0156-2g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2g · Anglès professional:** Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte.
- **CE externs combinats:**
  - **0846-1c · Canvis de forma permanent del cabell · RA1:** Reconeix els efectos que provocan els cambios de forma permanent en el cabell.
  - **1664-4a · Digitalització aplicada als sectors productius · RA4:** Identifica les tecnologías habilitadoras (THD) actuales que definen un sistema digitalizado.
  - **0842-7a · Pentinats i recollits · RA7:** Estableix tècniques bàsiques de manteniment del pentinat i del recollit.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2g + 0846-1c + 1664-4a + 0842-7a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 63. Incidència professional i millora: 0156-2g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2g · Anglès professional:** Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte.
- **CE externs combinats:**
  - **0849-1g · Anàlisi capil·lar · RA1:** Relaciona les características de una pell normal amb sus posibles variaciones i su repercusión capil·lar.
  - **1709-2h · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els requisits i les condicions per a la vigilància de la salut de la persona treballadora i la seva importància com a mesura de prevenció.
  - **0845-7g · Tècniques de tall de cabells · RA7:** Aplica tècniques de finalització del tall de cabell.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2g + 0849-1g + 1709-2h + 0845-7g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 64. Producte final per al client o portafolis: 0156-2g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2g · Anglès professional:** Interpreta el missatge recibido a través de soportes telemáticos o cualquier otro tipo de soporte.
- **CE externs combinats:**
  - **1664-4b · Digitalització aplicada als sectors productius · RA4:** Descriu les características i aplicaciones del IoT, IA (Inteligencia Artificial), Big Data, tecnología 5G, la robótica colaborativa, Blockchain, Ciberseguretat, fabricación aditiva, realidad virtual, gemelos digitales, entre otras.
  - **0842-7b · Pentinats i recollits · RA7:** Selecciona els cosmètics de manteniment necessaris.
  - **0844-2d · Cosmètica per a perruqueria · RA2:** Estableix la diferencia entre composición cuantitativa i cualitativa.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2g + 1664-4b + 0842-7b + 0844-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 17. 0156-2h — Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 65. Repte pràctic de diagnòstic i decisió: 0156-2h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2h · Anglès professional:** Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional.
- **CE externs combinats:**
  - **0846-1e · Canvis de forma permanent del cabell · RA1:** Justifica les ventajas e inconvenientes dels métodos de realización.
  - **1664-4c · Digitalització aplicada als sectors productius · RA4:** Descriu la contribución de les THD a la mejora de la productividad i la eficiencia dels sistemas productivos o de prestación de servicios.
  - **0842-7c · Pentinats i recollits · RA7:** Identifica els útils necessaris per a la conservació del pentinat o del recollit.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2h + 0846-1e + 1664-4c + 0842-7c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 66. Taller d’execució guiada: 0156-2h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2h · Anglès professional:** Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional.
- **CE externs combinats:**
  - **0849-1i · Anàlisi capil·lar · RA1:** Especifica els efectos del sol en la pell i el cabell.
  - **1709-3a · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza els drets i les obligacions derivats de la relació laboral, així com les condicions de treball pactades en un conveni col·lectiu aplicable en el sector professional relacionat amb el títol.
  - **0845-7i · Tècniques de tall de cabells · RA7:** Manté una actitud ordenada i metòdica en les activitats de treball.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2h + 0849-1i + 1709-3a + 0845-7i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 67. Incidència professional i millora: 0156-2h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2h · Anglès professional:** Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional.
- **CE externs combinats:**
  - **1664-4d · Digitalització aplicada als sectors productius · RA4:** Relaciona la alineación entre les unidades funcionales de les empresas que conforman el sistema i el objetivo del mismo.
  - **0842-7d · Pentinats i recollits · RA7:** Identifica els factors que modifiquen la durada del pentinat.
  - **0844-2f · Cosmètica per a perruqueria · RA2:** Determina les pautas delaboración en función del tipo de cosmètic que se va a preparar.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2h + 1664-4d + 0842-7d + 0844-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 68. Producte final per al client o portafolis: 0156-2h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2h · Anglès professional:** Reconeix la finalidad de diferents textos escrits en cualquier soporte, en lengua estàndard i relacionados amb la actividad professional.
- **CE externs combinats:**
  - **1709-3b · Itinerari personal per a l’ocupabilitat I · RA3:** Compara les principals modalitats de contractació i s’han localitzat els diferents models a les fonts oficials.
  - **0845-1a · Tècniques de tall de cabells · RA1:** Caracteritza els útils i les eines necessaris per al procés de tall.
  - **0846-2d · Canvis de forma permanent del cabell · RA2:** Identifica les alteraciones del cuero cabelludo i del cabell.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2h + 1709-3b + 0845-1a + 0846-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 18. 0156-2i — Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes.

**RA del mòdul eix:** 0156-RA2. Comprensió d’informació professional en textos escrits senzills en anglès.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 69. Repte pràctic de diagnòstic i decisió: 0156-2i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2i · Anglès professional:** Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes.
- **CE externs combinats:**
  - **0849-2a · Anàlisi capil·lar · RA2:** Identifica els aparells usados en el análisis.
  - **1709-3c · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica les característiques definitòries dels nous entorns d'organització del treball i els drets que comporta, així com les mesures vigents per a la conciliació de la vida laboral i familiar.
  - **0845-1b · Tècniques de tall de cabells · RA1:** Selecciona models bàsics de tisores, navalles i màquines.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-2i + 0849-2a + 1709-3c + 0845-1b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 70. Taller d’execució guiada: 0156-2i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2i · Anglès professional:** Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes.
- **CE externs combinats:**
  - **1664-4f · Digitalització aplicada als sectors productius · RA4:** Relaciona les tecnologías disruptivas amb aplicaciones concretas en els sectores productivos.
  - **0842-7f · Pentinats i recollits · RA7:** Proposa mesures per optimitzar el manteniment del pentinat i del recollit.
  - **0844-2h · Cosmètica per a perruqueria · RA2:** Segueix les pautas de limpieza i colocación del material de laboratorio empleado.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-2i + 1664-4f + 0842-7f + 0844-2h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 71. Incidència professional i millora: 0156-2i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2i · Anglès professional:** Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes.
- **CE externs combinats:**
  - **1709-3d · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els diferents components del rebut de salari.
  - **0845-1c · Tècniques de tall de cabells · RA1:** Aplica mesures de protecció del professional i de la persona usuària.
  - **0846-2f · Canvis de forma permanent del cabell · RA2:** Dissenya procediments de treball personalizados.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-2i + 1709-3d + 0845-1c + 0846-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 72. Producte final per al client o portafolis: 0156-2i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-2i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-2i · Anglès professional:** Extreu informació específica de textos de diferente naturaleza, relativos a su profesión i contenidos en diferents soportes.
- **CE externs combinats:**
  - **0842-1a · Pentinats i recollits · RA1:** Relaciona els tipus d’oval i les siluetes amb el pentinat adequat.
  - **0844-3a · Cosmètica per a perruqueria · RA3:** Diferencia els tipos de cosmètics que se emplean en un establecimiento de perruqueria.
  - **0849-2f · Anàlisi capil·lar · RA2:** Determina les medidas de protecció per a usuaris i professionals.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-2i + 0842-1a + 0844-3a + 0849-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 19. 0156-3a — Determina els registros más adequats per a la emisión del missatge.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 73. Repte pràctic de diagnòstic i decisió: 0156-3a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3a · Anglès professional:** Determina els registros más adequats per a la emisión del missatge.
- **CE externs combinats:**
  - **1664-4h · Digitalització aplicada als sectors productius · RA4:** Descriu les mejoras producidas en el sistema i en cada una de sus etapas.
  - **0842-1b · Pentinats i recollits · RA1:** Relaciona els tipus de recollit amb l’anàlisi morfològica i capil·lar.
  - **0844-3b · Cosmètica per a perruqueria · RA3:** Relaciona el mecanismo de acción de un champú amb els ingredientes activos que contiene.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3a + 1664-4h + 0842-1b + 0844-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 74. Taller d’execució guiada: 0156-3a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3a · Anglès professional:** Determina els registros más adequats per a la emisión del missatge.
- **CE externs combinats:**
  - **1709-3f · Itinerari personal per a l’ocupabilitat I · RA3:** Valora el paper de la Seguretat Social com a pilar essencial per millorar la qualitat de vida dels ciutadans.
  - **0845-1e · Tècniques de tall de cabells · RA1:** Selecciona la llenceria i els útils auxiliars adequats per al tall.
  - **0846-3a · Canvis de forma permanent del cabell · RA3:** Condiciona les instalaciones per a que estén en óptimas condiciones de seguretat e higiene.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3a + 1709-3f + 0845-1e + 0846-3a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 75. Incidència professional i millora: 0156-3a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3a · Anglès professional:** Determina els registros más adequats per a la emisión del missatge.
- **CE externs combinats:**
  - **0842-1c · Pentinats i recollits · RA1:** Diferencia les característiques del cabell i la seva relació amb el pentinat.
  - **0844-3c · Cosmètica per a perruqueria · RA3:** Relaciona la composición de un acondicionador amb els efectos que origina en la fibra capil·lar.
  - **0849-3b · Anàlisi capil·lar · RA3:** Identifica els dades que permiten obtener informació útil per a el análisis capil·lar.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3a + 0842-1c + 0844-3c + 0849-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 76. Producte final per al client o portafolis: 0156-3a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3a · Anglès professional:** Determina els registros más adequats per a la emisión del missatge.
- **CE externs combinats:**
  - **0845-1f · Tècniques de tall de cabells · RA1:** Aplica protocols d’higiene i manteniment d’eines i útils.
  - **0846-3b · Canvis de forma permanent del cabell · RA3:** Aplica les medidas de protecció i seguretat del professional i el usuari.
  - **1664-5e · Digitalització aplicada als sectors productius · RA5:** Elabora un diagrama de bloques del sistema digitalizado.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3a + 0845-1f + 0846-3b + 1664-5e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 20. 0156-3b — Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 77. Repte pràctic de diagnòstic i decisió: 0156-3b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3b · Anglès professional:** Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació.
- **CE externs combinats:**
  - **1709-3h · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza el contingut del dret fonamental a la llibertat sindical i les diferents modalitats de representació de les persones treballadores a l’empresa.
  - **0845-1g · Tècniques de tall de cabells · RA1:** Segueix la normativa vigent de control d’útils tallants.
  - **0846-3c · Canvis de forma permanent del cabell · RA3:** Identifica les posturas corporales adequadas per a prevenir accidentes.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3b + 1709-3h + 0845-1g + 0846-3c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 78. Taller d’execució guiada: 0156-3b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3b · Anglès professional:** Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació.
- **CE externs combinats:**
  - **0842-1e · Pentinats i recollits · RA1:** Classifica els pentinats segons el tipus d’esdeveniment, la circumstància, el tipus d’oval i la longitud del cabell.
  - **0844-3e · Cosmètica per a perruqueria · RA3:** Estableix les transformaciones que tienen lugar en la fibra capil·lar en els processos de cambio de forma temporal del cabell.
  - **0849-3d · Anàlisi capil·lar · RA3:** Maneja la lupa i la luz de wood per a la observación del estado del cabell i cuero cabelludo.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3b + 0842-1e + 0844-3e + 0849-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 79. Incidència professional i millora: 0156-3b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3b · Anglès professional:** Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació.
- **CE externs combinats:**
  - **0845-2a · Tècniques de tall de cabells · RA2:** Identifica les diferències entre tècnica i estil de tall.
  - **0846-3d · Canvis de forma permanent del cabell · RA3:** Caracteritza els útils i eines necessaris per a el procés.
  - **1664-5g · Digitalització aplicada als sectors productius · RA5:** Analitza la mejora en la producción i gestión de residuos, entre otras.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3b + 0845-2a + 0846-3d + 1664-5g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 80. Producte final per al client o portafolis: 0156-3b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3b · Anglès professional:** Comunica utilizando fórmulas, nexos de unión, marcadores discursivos i estrategias de interacción acordes a la situación de comunicació.
- **CE externs combinats:**
  - **0844-3f · Cosmètica per a perruqueria · RA3:** Relaciona la aplicación dels cosmètics específicos del procés de cambio permanente del cabell amb els cambios químicos que tienen lugar en el mismo.
  - **0849-3e · Anàlisi capil·lar · RA3:** Aplica métodos de exploración del cabell.
  - **1709-4d · Itinerari personal per a l’ocupabilitat I · RA4:** Assenyala les preferències professionals, els interessos i les metes en el marc d'un projecte professional.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3b + 0844-3f + 0849-3e + 1709-4d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 21. 0156-3c — Descriu hechos breves e imprevistos relacionados amb su profesión.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 81. Repte pràctic de diagnòstic i decisió: 0156-3c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3c · Anglès professional:** Descriu hechos breves e imprevistos relacionados amb su profesión.
- **CE externs combinats:**
  - **0842-1g · Pentinats i recollits · RA1:** Aplica mètodes per determinar tendències en pentinats i recollits a partir de fonts documentals.
  - **0844-3g · Cosmètica per a perruqueria · RA3:** Identifica els componentes dels cosmètics per a cambios de color i su acción sobre el tallo capil·lar.
  - **0849-3f · Anàlisi capil·lar · RA3:** Comprova la posible existencia de alteraciones.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3c + 0842-1g + 0844-3g + 0849-3f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 82. Taller d’execució guiada: 0156-3c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3c · Anglès professional:** Descriu hechos breves e imprevistos relacionados amb su profesión.
- **CE externs combinats:**
  - **0845-2c · Tècniques de tall de cabells · RA2:** Determina els útils emprats en cada tècnica de tall.
  - **0846-3f · Canvis de forma permanent del cabell · RA3:** Selecciona els moldes en función de les características del cabell i el resultat deseado.
  - **1664-1a · Digitalització aplicada als sectors productius · RA1:** Identifica les etapas «típicas» dels modelos basados en EL i modelos basados en EC.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3c + 0845-2c + 0846-3f + 1664-1a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 83. Incidència professional i millora: 0156-3c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3c · Anglès professional:** Descriu hechos breves e imprevistos relacionados amb su profesión.
- **CE externs combinats:**
  - **0844-3h · Cosmètica per a perruqueria · RA3:** Reconeix els cosmètics per a les alteraciones capil·lares que se emplean habitualmente en establecimientos de perruqueria.
  - **0849-3g · Anàlisi capil·lar · RA3:** Realitza la recogida de informació.
  - **1709-4f · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica les fortaleses, les debilitats, les amenaces i les oportunitats pròpies per a la inserció professional.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3c + 0844-3h + 0849-3g + 1709-4f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 84. Producte final per al client o portafolis: 0156-3c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3c · Anglès professional:** Descriu hechos breves e imprevistos relacionados amb su profesión.
- **CE externs combinats:**
  - **0846-3g · Canvis de forma permanent del cabell · RA3:** Selecciona els cosmètics adequat per a els cambios de forma permanent.
  - **1664-1b · Digitalització aplicada als sectors productius · RA1:** Analitza cada etapa dels modelos EL i EC i su repercusión en el medi ambient.
  - **0842-2c · Pentinats i recollits · RA2:** Selecciona els motlles en funció de l’efecte desitjat.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3c + 0846-3g + 1664-1b + 0842-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 22. 0156-3d — Utilitza correctamente la terminología de la profesión.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 85. Repte pràctic de diagnòstic i decisió: 0156-3d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3d · Anglès professional:** Utilitza correctamente la terminología de la profesión.
- **CE externs combinats:**
  - **0845-2e · Tècniques de tall de cabells · RA2:** Seqüencia les fases d’execució de cada tècnica.
  - **0846-3h · Canvis de forma permanent del cabell · RA3:** Manipula i conservado els productos químicos i cosmètics en condiciones de seguretat e higiene.
  - **1664-1c · Digitalització aplicada als sectors productius · RA1:** Valora la importancia del reciclaje en els modelos económicos.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3d + 0845-2e + 0846-3h + 1664-1c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 86. Taller d’execució guiada: 0156-3d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3d · Anglès professional:** Utilitza correctamente la terminología de la profesión.
- **CE externs combinats:**
  - **0844-4a · Cosmètica per a perruqueria · RA4:** Identifica els cosmètics per a manicura i pedicura.
  - **0849-4a · Anàlisi capil·lar · RA4:** Caracteritza les fases de un protocolo.
  - **1709-4h · Itinerari personal per a l’ocupabilitat I · RA4:** Valora fites importants en la trajectòria vital amb valor professionalitzador.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3d + 0844-4a + 0849-4a + 1709-4h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 87. Incidència professional i millora: 0156-3d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3d · Anglès professional:** Utilitza correctamente la terminología de la profesión.
- **CE externs combinats:**
  - **0846-4a · Canvis de forma permanent del cabell · RA4:** Comprova el estado del cabell.
  - **1664-1d · Digitalització aplicada als sectors productius · RA1:** Identifica processos reales basados en EL.
  - **0842-2e · Pentinats i recollits · RA2:** Justifica l’ús d’ornaments i altres complements.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3d + 0846-4a + 1664-1d + 0842-2e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 88. Producte final per al client o portafolis: 0156-3d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3d · Anglès professional:** Utilitza correctamente la terminología de la profesión.
- **CE externs combinats:**
  - **0849-4b · Anàlisi capil·lar · RA4:** Estableix les pautas delaboración de protocolos per a els cuidados capil·lares en descamaciones, cabell seco i frágil.
  - **1709-4i · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica els itineraris formatius professionals relacionats amb el perfil professional.
  - **0845-3b · Tècniques de tall de cabells · RA3:** Estableix pautes per detectar necessitats i demandes de la persona usuària.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3d + 0849-4b + 1709-4i + 0845-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 23. 0156-3e — Expressa sentimientos, ideas u opiniones.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 89. Repte pràctic de diagnòstic i decisió: 0156-3e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3e · Anglès professional:** Expressa sentimientos, ideas u opiniones.
- **CE externs combinats:**
  - **0844-4c · Cosmètica per a perruqueria · RA4:** Relaciona la forma cosmética amb el modo de aplicación.
  - **0849-4c · Anàlisi capil·lar · RA4:** Elabora protocolos per a el mantenimiento de cabells teñidos, decolorados i permanentados.
  - **1709-4j · Itinerari personal per a l’ocupabilitat I · RA4:** Formula objectius professionals i s'han determinat metes personals i professionals per millorar l'ocupabilitat i les condicions d'inserció laboral.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3e + 0844-4c + 0849-4c + 1709-4j.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 90. Taller d’execució guiada: 0156-3e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3e · Anglès professional:** Expressa sentimientos, ideas u opiniones.
- **CE externs combinats:**
  - **0846-4c · Canvis de forma permanent del cabell · RA4:** Realitza la repartición zonal del cabell en función del montaje.
  - **1664-1f · Digitalització aplicada als sectors productius · RA1:** Compara els modelos anteriores en relación amb su impacto medioambiental i els ODS (Objetivos de Desarrollo Sostenible).
  - **0842-2g · Pentinats i recollits · RA2:** Segueix pautes de neteja dels útils després de l’ús.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3e + 0846-4c + 1664-1f + 0842-2g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 91. Incidència professional i millora: 0156-3e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3e · Anglès professional:** Expressa sentimientos, ideas u opiniones.
- **CE externs combinats:**
  - **0849-4d · Anàlisi capil·lar · RA4:** Determina els medios, tècniques i materials necessaris.
  - **1709-4k · Itinerari personal per a l’ocupabilitat I · RA4:** Traça un pla d’acció per desenvolupar les àrees de millora i potenciar les fortaleses personals amb valor per a l’ocupació.
  - **0845-3d · Tècniques de tall de cabells · RA3:** Selecciona imatges i fotografies de pentinats segons l’estil de tall proposat.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3e + 0849-4d + 1709-4k + 0845-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 92. Producte final per al client o portafolis: 0156-3e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3e · Anglès professional:** Expressa sentimientos, ideas u opiniones.
- **CE externs combinats:**
  - **1664-2a · Digitalització aplicada als sectors productius · RA2:** Relaciona els sistemas ciber físicos amb la evolución industrial.
  - **0842-2h · Pentinats i recollits · RA2:** Col·loca els mitjans necessaris al tocador i a l’àrea de treball.
  - **0844-4h · Cosmètica per a perruqueria · RA4:** Identifica la cosmética masculina de protecció i de tratamiento.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3e + 1664-2a + 0842-2h + 0844-4h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 24. 0156-3f — Enumera les actividades propias de la tarea professional.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 93. Repte pràctic de diagnòstic i decisió: 0156-3f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3f · Anglès professional:** Enumera les actividades propias de la tarea professional.
- **CE externs combinats:**
  - **0846-4e · Canvis de forma permanent del cabell · RA4:** Verifica el montaje de bigudíes.
  - **1664-2b · Digitalització aplicada als sectors productius · RA2:** Analitza el cambio producido en els sistemas automatizados.
  - **0842-3a · Pentinats i recollits · RA3:** Identifica els requisits del rentacaps i de la butaca.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3f + 0846-4e + 1664-2b + 0842-3a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 94. Taller d’execució guiada: 0156-3f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3f · Anglès professional:** Enumera les actividades propias de la tarea professional.
- **CE externs combinats:**
  - **0849-5a · Anàlisi capil·lar · RA5:** Determina els tipos de maniobras del masaje capil·lar.
  - **1709-5b · Itinerari personal per a l’ocupabilitat I · RA5:** Identifica l’ocupabilitat com a capacitat d’adaptació a l’entorn laboral.
  - **0845-3f · Tècniques de tall de cabells · RA3:** Realitza esbossos gràfics per a la proposta de tall.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3f + 0849-5a + 1709-5b + 0845-3f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 95. Incidència professional i millora: 0156-3f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3f · Anglès professional:** Enumera les actividades propias de la tarea professional.
- **CE externs combinats:**
  - **1664-2c · Digitalització aplicada als sectors productius · RA2:** Descriu la combinación de la parte física de les industrias amb el software, IoT (Internet de les cosas), comunicaciones, entre otros.
  - **0842-3b · Pentinats i recollits · RA3:** Acomoda la persona usuària al rentacaps.
  - **0844-5b · Cosmètica per a perruqueria · RA5:** Relaciona les alteraciones en la composición dels productos cosmètics amb els cambios que se originan en sus características organolépticas.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3f + 1664-2c + 0842-3b + 0844-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 96. Producte final per al client o portafolis: 0156-3f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3f · Anglès professional:** Enumera les actividades propias de la tarea professional.
- **CE externs combinats:**
  - **1709-5c · Itinerari personal per a l’ocupabilitat I · RA5:** Coneix i utilitzat eines, fonts d'informació, connexions i activitats per configurar un entorn personal d'aprenentatge per a l'ocupabilitat.
  - **0845-3g · Tècniques de tall de cabells · RA3:** Utilitza aplicacions informàtiques per elaborar dissenys de tall del cabell.
  - **0846-4j · Canvis de forma permanent del cabell · RA4:** Aplica les normas de prevenció, seguretat i protecció ambiental estipuladas, durante el procés de treball.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3f + 1709-5c + 0845-3g + 0846-4j.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 25. 0156-3g — Descriu i secuenciado un procés de treball de su competencia.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 97. Repte pràctic de diagnòstic i decisió: 0156-3g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3g · Anglès professional:** Descriu i secuenciado un procés de treball de su competencia.
- **CE externs combinats:**
  - **0849-5c · Anàlisi capil·lar · RA5:** Aplica tècniques de masaje en els cuidados capil·lares.
  - **1709-5d · Itinerari personal per a l’ocupabilitat I · RA5:** Posa en pràctica la competència digital per configurar un entorn personal d’aprenentatge per a l’ocupabilitat.
  - **0845-4a · Tècniques de tall de cabells · RA4:** Estableix pautes per al maneig i la subjecció de la tisora.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3g + 0849-5c + 1709-5d + 0845-4a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 98. Taller d’execució guiada: 0156-3g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3g · Anglès professional:** Descriu i secuenciado un procés de treball de su competencia.
- **CE externs combinats:**
  - **1664-2e · Digitalització aplicada als sectors productius · RA2:** Relaciona la migración a entornos 4.0 amb la mejora dels resultats de les empresas.
  - **0842-3d · Pentinats i recollits · RA3:** Justifica les posicions ergonòmiques de la persona usuària i del professional durant la higiene capil·lar.
  - **0844-5d · Cosmètica per a perruqueria · RA5:** Especifica les pautas correctas de manipulación dels productos cosmètics per a garantizar unas condiciones higiénico-sanitarias idóneas de aplicación.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3g + 1664-2e + 0842-3d + 0844-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 99. Incidència professional i millora: 0156-3g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3g · Anglès professional:** Descriu i secuenciado un procés de treball de su competencia.
- **CE externs combinats:**
  - **1709-5e · Itinerari personal per a l’ocupabilitat I · RA5:** Analitza el concepte d'identitat digital i el seu impacte en l'ocupabilitat.
  - **0845-4b · Tècniques de tall de cabells · RA4:** Relaciona els moviments de tisora amb el tipus de línia.
  - **0846-5b · Canvis de forma permanent del cabell · RA5:** Caracteritza la tècnica de aplicación.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3g + 1709-5e + 0845-4b + 0846-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 100. Producte final per al client o portafolis: 0156-3g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3g · Anglès professional:** Descriu i secuenciado un procés de treball de su competencia.
- **CE externs combinats:**
  - **0842-3e · Pentinats i recollits · RA3:** Estableix les fases i pautes d’aplicació.
  - **0844-5e · Cosmètica per a perruqueria · RA5:** Analitza les consecuencias de una incorrecta manipulación dels productos cosmètics.
  - **0849-5h · Anàlisi capil·lar · RA5:** Justifica la valoración del resultat obtenido como factor de calidad del procés.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3g + 0842-3e + 0844-5e + 0849-5h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 26. 0156-3h — Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 101. Repte pràctic de diagnòstic i decisió: 0156-3h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3h · Anglès professional:** Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados.
- **CE externs combinats:**
  - **1664-3a · Digitalització aplicada als sectors productius · RA3:** Identifica els diferentes niveles de la cloud /nube.
  - **0842-3f · Pentinats i recollits · RA3:** Realitza maniobres de massatge per a la neteja del cabell i del cuir cabellut.
  - **0844-5f · Cosmètica per a perruqueria · RA5:** Aplica les pautas de recogida dels productos cosmètics contaminados y/o alterados, respetando la normativa vigente i el medi ambient.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3h + 1664-3a + 0842-3f + 0844-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 102. Taller d’execució guiada: 0156-3h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3h · Anglès professional:** Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados.
- **CE externs combinats:**
  - **1709-5g · Itinerari personal per a l’ocupabilitat I · RA5:** Elabora el pla de desenvolupament individual com a eina per a la millora de l’ocupabilitat.
  - **0845-4d · Tècniques de tall de cabells · RA4:** Determina les particions del cabell prèvies al tall.
  - **0846-5d · Canvis de forma permanent del cabell · RA5:** Aplica els líquidos reductores per a el alisado permanente.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3h + 1709-5g + 0845-4d + 0846-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 103. Incidència professional i millora: 0156-3h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3h · Anglès professional:** Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados.
- **CE externs combinats:**
  - **0842-3g · Pentinats i recollits · RA3:** Selecciona cosmètics en funció de les característiques del cabell.
  - **0844-6a · Cosmètica per a perruqueria · RA6:** Identifica les líneas comerciales de cosmètics per a perruqueria.
  - **0849-6b · Anàlisi capil·lar · RA6:** Valora la aplicación de normas deontológicas en el desarrollo professional.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3h + 0842-3g + 0844-6a + 0849-6b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 104. Producte final per al client o portafolis: 0156-3h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3h · Anglès professional:** Justifica la aceptación o no de propuestas realizadas haciendo uso de normas de tallsía i de modales apropiados.
- **CE externs combinats:**
  - **0845-4e · Tècniques de tall de cabells · RA4:** Estableix paràmetres per a la realització del tall.
  - **0846-5e · Canvis de forma permanent del cabell · RA5:** Controla el procés durante el tiempo de exposición.
  - **1664-4a · Digitalització aplicada als sectors productius · RA4:** Identifica les tecnologías habilitadoras (THD) actuales que definen un sistema digitalizado.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3h + 0845-4e + 0846-5e + 1664-4a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 27. 0156-3i — Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 105. Repte pràctic de diagnòstic i decisió: 0156-3i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3i · Anglès professional:** Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos.
- **CE externs combinats:**
  - **1709-5i · Itinerari personal per a l’ocupabilitat I · RA5:** Dissenya l'entorn d'aprenentatge que permet assolir el pla de desenvolupament individual.
  - **0845-4f · Tècniques de tall de cabells · RA4:** Valora la importància de la metxa guia.
  - **0846-5f · Canvis de forma permanent del cabell · RA5:** Aplica el neutralizante siguiendo el procediment establecido.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3i + 1709-5i + 0845-4f + 0846-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 106. Taller d’execució guiada: 0156-3i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3i · Anglès professional:** Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos.
- **CE externs combinats:**
  - **0842-3i · Pentinats i recollits · RA3:** Aplica tècniques complementàries i sensorials en la higiene capil·lar.
  - **0844-6c · Cosmètica per a perruqueria · RA6:** Especifica els establecimientos de venta de cosmètics per a perruqueria.
  - **0849-6d · Anàlisi capil·lar · RA6:** Valora la importancia i repercusión del treball honesto.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3i + 0842-3i + 0844-6c + 0849-6d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 107. Incidència professional i millora: 0156-3i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3i · Anglès professional:** Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos.
- **CE externs combinats:**
  - **0845-4g · Tècniques de tall de cabells · RA4:** Seqüencia el tall en l’ordre establert.
  - **0846-5g · Canvis de forma permanent del cabell · RA5:** Realitza els ajustes necessaris en el procés.
  - **1664-4c · Digitalització aplicada als sectors productius · RA4:** Descriu la contribución de les THD a la mejora de la productividad i la eficiencia dels sistemas productivos o de prestación de servicios.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3i + 0845-4g + 0846-5g + 1664-4c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 108. Producte final per al client o portafolis: 0156-3i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3i · Anglès professional:** Intercanvia amb relativa fluidez, informació específica i detallada utilizando frases de estructura sencilla i diferentes soportes telemáticos.
- **CE externs combinats:**
  - **0844-6d · Cosmètica per a perruqueria · RA6:** Realitza fitxas informativas sobre els efectos i la aplicación de cosmètics.
  - **0849-6e · Anàlisi capil·lar · RA6:** Justifica la necesidad del secreto professional en la profesión.
  - **1709-2b · Itinerari personal per a l’ocupabilitat I · RA2:** Classifica i descrit els tipus de danys professionals, amb una referència especial als accidents de treball i malalties professionals, relacionats amb el perfil professional del títol.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3i + 0844-6d + 0849-6e + 1709-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 28. 0156-3j — Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 109. Repte pràctic de diagnòstic i decisió: 0156-3j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3j · Anglès professional:** Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats.
- **CE externs combinats:**
  - **0842-4b · Pentinats i recollits · RA4:** Estableix les característiques de les diferents tècniques de canvi de forma.
  - **0844-6e · Cosmètica per a perruqueria · RA6:** Relaciona el consejo professional amb la mejora del servicio de venta de cosmètics.
  - **0849-6f · Anàlisi capil·lar · RA6:** Treballa el respeto a la diferencia.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3j + 0842-4b + 0844-6e + 0849-6f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 110. Taller d’execució guiada: 0156-3j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3j · Anglès professional:** Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats.
- **CE externs combinats:**
  - **0845-5a · Tècniques de tall de cabells · RA5:** Estableix diferències entre el tall amb navalla i el tall amb tisora.
  - **0846-5i · Canvis de forma permanent del cabell · RA5:** Determina els cuidados posteriores al desrizado.
  - **1664-4e · Digitalització aplicada als sectors productius · RA4:** Relaciona la implantación de les tecnologías habilitadoras (sensórica, tratamiento de dades, automatización i comunicaciones, entre otras) amb la reducción de costes i la mejora de la competitividad.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3j + 0845-5a + 0846-5i + 1664-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 111. Incidència professional i millora: 0156-3j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3j · Anglès professional:** Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats.
- **CE externs combinats:**
  - **0844-6f · Cosmètica per a perruqueria · RA6:** Determina la importancia de mantener una constante actualización en productos de innovación en perruqueria.
  - **0849-6g · Anàlisi capil·lar · RA6:** Valora la repercusión de la ley de protecció de dades en el ejercicio professional de la perruqueria.
  - **1709-2d · Itinerari personal per a l’ocupabilitat I · RA2:** Analitza els protocols d'actuació en cas d'emergència.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3j + 0844-6f + 0849-6g + 1709-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 112. Producte final per al client o portafolis: 0156-3j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3j · Anglès professional:** Realitza de manera clara, presentaciones breves i preparadas sobre un tema dentro de su especialidad, haciendo uso dels protocolos adequats.
- **CE externs combinats:**
  - **0846-5j · Canvis de forma permanent del cabell · RA5:** Identifica tendencias i nuevos productos de desrizado i alisado.
  - **1664-4f · Digitalització aplicada als sectors productius · RA4:** Relaciona les tecnologías disruptivas amb aplicaciones concretas en els sectores productivos.
  - **0842-4g · Pentinats i recollits · RA4:** Justifica l’ús de tècniques auxiliars i associades per realitzar el pentinat.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3j + 0846-5j + 1664-4f + 0842-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 29. 0156-3k — Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 113. Repte pràctic de diagnòstic i decisió: 0156-3k

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3k** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3k · Anglès professional:** Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias.
- **CE externs combinats:**
  - **0845-5c · Tècniques de tall de cabells · RA5:** Realitza el muntatge i desmuntatge de la fulla.
  - **0846-6a · Canvis de forma permanent del cabell · RA6:** Determina els factores que afectan al resultat.
  - **1664-4g · Digitalització aplicada als sectors productius · RA4:** Defineix els sistemas de almacenamiento de dades no convencionales i el acceso a els mismos desde cada unidad.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3k + 0845-5c + 0846-6a + 1664-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 114. Taller d’execució guiada: 0156-3k

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3k** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3k · Anglès professional:** Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias.
- **CE externs combinats:**
  - **0844-1a · Cosmètica per a perruqueria · RA1:** Identifica les características del producto cosmètic segons la reglamentación técnico-sanitaria.
  - **0849-1b · Anàlisi capil·lar · RA1:** Caracteritza la estructura de la pell i sus glándulas.
  - **1709-2f · Itinerari personal per a l’ocupabilitat I · RA2:** Classifica les diferents formes de gestió de la prevenció a l'empresa o organisme equiparat, en funció dels diferents criteris establerts a la normativa sobre prevenció de riscos laborals i s’han determinat les formes de representació de les persones treballadores a l'empresa o organisme equiparat en matèria de prevenció de riscs.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3k + 0844-1a + 0849-1b + 1709-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 115. Incidència professional i millora: 0156-3k

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3k** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3k · Anglès professional:** Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias.
- **CE externs combinats:**
  - **0846-6b · Canvis de forma permanent del cabell · RA6:** Relaciona els errores más frecuentes en la realización, amb la fase en la que s’han producido.
  - **1664-4h · Digitalització aplicada als sectors productius · RA4:** Descriu les mejoras producidas en el sistema i en cada una de sus etapas.
  - **0842-4i · Pentinats i recollits · RA4:** Relaciona les tècniques d’acabat amb el tipus de pentinat.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3k + 0846-6b + 1664-4h + 0842-4i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 116. Producte final per al client o portafolis: 0156-3k

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3k** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3k · Anglès professional:** Comunica espontáneamente adoptando un nivel de formalidad adequat a les circunstancias.
- **CE externs combinats:**
  - **0849-1c · Anàlisi capil·lar · RA1:** Especifica els tipos de pelo, estableciéndose sus características i criteris de clasificación.
  - **1709-2g · Itinerari personal per a l’ocupabilitat I · RA2:** Valora la importància de l'existència d'un pla preventiu a l'empresa o organisme equiparat que inclogui la seqüenciació d'actuacions que cal realitzar en cas d'emergència i s’ha reflexionat sobre el seu contingut.
  - **0845-5h · Tècniques de tall de cabells · RA5:** Aplica procediments de realització del tall amb navalla.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3k + 0849-1c + 1709-2g + 0845-5h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 30. 0156-3l — Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 117. Repte pràctic de diagnòstic i decisió: 0156-3l

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3l** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3l · Anglès professional:** Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball.
- **CE externs combinats:**
  - **0844-1c · Cosmètica per a perruqueria · RA1:** Relaciona les características de les sustancias empleadas en els cosmètics, amb la función que desempeñan.
  - **0849-1d · Anàlisi capil·lar · RA1:** Justifica el carácter cíclico del crecimiento piloso.
  - **1709-2h · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els requisits i les condicions per a la vigilància de la salut de la persona treballadora i la seva importància com a mesura de prevenció.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3l + 0844-1c + 0849-1d + 1709-2h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 118. Taller d’execució guiada: 0156-3l

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3l** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3l · Anglès professional:** Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball.
- **CE externs combinats:**
  - **0846-6d · Canvis de forma permanent del cabell · RA6:** Proposa medidas de asesoramiento al usuari per a el mantenimiento del treball técnico realizado.
  - **1664-5b · Digitalització aplicada als sectors productius · RA5:** Identifica les etapas susceptibles de ser digitalizadas.
  - **0842-5b · Pentinats i recollits · RA5:** Selecciona eines, productes i complements.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3l + 0846-6d + 1664-5b + 0842-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 119. Incidència professional i millora: 0156-3l

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3l** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3l · Anglès professional:** Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball.
- **CE externs combinats:**
  - **0849-1e · Anàlisi capil·lar · RA1:** Reconeix les características i componentes del cabell.
  - **1709-2i · Itinerari personal per a l’ocupabilitat I · RA2:** Identifica les tècniques bàsiques de primers auxilis que han de ser aplicades al lloc de l'accident en cas de diferents tipus de danys i la composició i ús de la farmaciola.
  - **0845-6b · Tècniques de tall de cabells · RA6:** Selecciona accessoris i útils segons la longitud desitjada del cabell.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3l + 0849-1e + 1709-2i + 0845-6b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 120. Producte final per al client o portafolis: 0156-3l

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3l** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3l · Anglès professional:** Respon preguntas relativas a su vida socio-professional, incluidas les propias de una entrevista de treball.
- **CE externs combinats:**
  - **1664-5c · Digitalització aplicada als sectors productius · RA5:** Defineix les tecnologías implicadas en cada una de les etapas.
  - **0842-5c · Pentinats i recollits · RA5:** Diferencia les tècniques d’execució de diferents trenats.
  - **0844-2b · Cosmètica per a perruqueria · RA2:** Realitza les operaciones básicas per a elaborar cosmètics: medidas de peso i de volumen.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3l + 1664-5c + 0842-5c + 0844-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 31. 0156-3m — Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión.

**RA del mòdul eix:** 0156-RA3. Producció de missatges orals senzills, clars i estructurats en anglès professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 121. Repte pràctic de diagnòstic i decisió: 0156-3m

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3m** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3m · Anglès professional:** Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión.
- **CE externs combinats:**
  - **0846-6f · Canvis de forma permanent del cabell · RA6:** Segueix el protocolo de actuación en casos de irritaciones i alergias.
  - **1664-5d · Digitalització aplicada als sectors productius · RA5:** Estableix la conexión de les etapas digitalizadas amb el resto del sistema.
  - **0842-5d · Pentinats i recollits · RA5:** Estableix el mode de realització d’enrotllats, anelles, retorçats i bucles.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-3m + 0846-6f + 1664-5d + 0842-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 122. Taller d’execució guiada: 0156-3m

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3m** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3m · Anglès professional:** Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión.
- **CE externs combinats:**
  - **0849-1g · Anàlisi capil·lar · RA1:** Relaciona les características de una pell normal amb sus posibles variaciones i su repercusión capil·lar.
  - **1709-3b · Itinerari personal per a l’ocupabilitat I · RA3:** Compara les principals modalitats de contractació i s’han localitzat els diferents models a les fonts oficials.
  - **0845-6d · Tècniques de tall de cabells · RA6:** Verifica l’estat de la màquina.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-3m + 0849-1g + 1709-3b + 0845-6d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 123. Incidència professional i millora: 0156-3m

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3m** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3m · Anglès professional:** Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión.
- **CE externs combinats:**
  - **1664-5e · Digitalització aplicada als sectors productius · RA5:** Elabora un diagrama de bloques del sistema digitalizado.
  - **0842-5e · Pentinats i recollits · RA5:** Estableix paràmetres de selecció de postissos en funció de l’estil de recollit.
  - **0844-2d · Cosmètica per a perruqueria · RA2:** Estableix la diferencia entre composición cuantitativa i cualitativa.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-3m + 1664-5e + 0842-5e + 0844-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 124. Producte final per al client o portafolis: 0156-3m

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-3m** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-3m · Anglès professional:** Sol·licita la reformulación del discurso o la aclaración de parte del mismo cuando s’ha considerado necesario per a una mejor comprensión.
- **CE externs combinats:**
  - **1709-3c · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica les característiques definitòries dels nous entorns d'organització del treball i els drets que comporta, així com les mesures vigents per a la conciliació de la vida laboral i familiar.
  - **0845-6e · Tècniques de tall de cabells · RA6:** Realitza tècniques de condicionament del cabell.
  - **0846-1e · Canvis de forma permanent del cabell · RA1:** Justifica les ventajas e inconvenientes dels métodos de realización.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-3m + 1709-3c + 0845-6e + 0846-1e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 32. 0156-4a — Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros).

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 125. Repte pràctic de diagnòstic i decisió: 0156-4a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4a · Anglès professional:** Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros).
- **CE externs combinats:**
  - **0849-1i · Anàlisi capil·lar · RA1:** Especifica els efectos del sol en la pell i el cabell.
  - **1709-3d · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els diferents components del rebut de salari.
  - **0845-6f · Tècniques de tall de cabells · RA6:** Estableix l’ordre de realització del tall amb màquina.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4a + 0849-1i + 1709-3d + 0845-6f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 126. Taller d’execució guiada: 0156-4a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4a · Anglès professional:** Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros).
- **CE externs combinats:**
  - **1664-5g · Digitalització aplicada als sectors productius · RA5:** Analitza la mejora en la producción i gestión de residuos, entre otras.
  - **0842-5g · Pentinats i recollits · RA5:** Justifica la combinació de tècniques per a l’elaboració del recollit.
  - **0844-2f · Cosmètica per a perruqueria · RA2:** Determina les pautas delaboración en función del tipo de cosmètic que se va a preparar.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4a + 1664-5g + 0842-5g + 0844-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 127. Incidència professional i millora: 0156-4a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4a · Anglès professional:** Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros).
- **CE externs combinats:**
  - **1709-3e · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els recursos laborals existents en les diferents vicissituds que es poden generar en la relació laboral.
  - **0845-6g · Tècniques de tall de cabells · RA6:** Aplica procediments establerts en el tall amb màquina.
  - **0846-2a · Canvis de forma permanent del cabell · RA2:** Identifica les demandas dels usuaris.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4a + 1709-3e + 0845-6g + 0846-2a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 128. Producte final per al client o portafolis: 0156-4a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4a · Anglès professional:** Selecciona les estrategias, estructuras, vocabulario i convenciones más adequadas per a el tipo de texto que se va a crear (fax, nota, carta o correo electrónico, entre otros).
- **CE externs combinats:**
  - **0842-5h · Pentinats i recollits · RA5:** Relaciona els mètodes de subjecció del recollit amb els útils i les eines apropiats.
  - **0844-2g · Cosmètica per a perruqueria · RA2:** Prepara cosmètics sencillos empleando les materias primas, el material i els equips adequats.
  - **0849-2d · Anàlisi capil·lar · RA2:** Estableix la forma de ocupació i mantenimiento.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4a + 0842-5h + 0844-2g + 0849-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 33. 0156-4b — Redacta textos breves relacionados amb aspectos cotidianos y/o professionals.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 129. Repte pràctic de diagnòstic i decisió: 0156-4b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4b · Anglès professional:** Redacta textos breves relacionados amb aspectos cotidianos y/o professionals.
- **CE externs combinats:**
  - **1664-1a · Digitalització aplicada als sectors productius · RA1:** Identifica les etapas «típicas» dels modelos basados en EL i modelos basados en EC.
  - **0842-5i · Pentinats i recollits · RA5:** Justifica l’ús d’elements accessoris com a factor potenciador de l’estil.
  - **0844-2h · Cosmètica per a perruqueria · RA2:** Segueix les pautas de limpieza i colocación del material de laboratorio empleado.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4b + 1664-1a + 0842-5i + 0844-2h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 130. Taller d’execució guiada: 0156-4b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4b · Anglès professional:** Redacta textos breves relacionados amb aspectos cotidianos y/o professionals.
- **CE externs combinats:**
  - **1709-3g · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza les principals prestacions derivades de la suspensió i l'extinció de la relació laboral.
  - **0845-7a · Tècniques de tall de cabells · RA7:** Caracteritza els estils de tall.
  - **0846-2c · Canvis de forma permanent del cabell · RA2:** Reconeix la influencia de otros processos de perruqueria (tinción i decoloració, entre otros) en la selección de la tècnica.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4b + 1709-3g + 0845-7a + 0846-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 131. Incidència professional i millora: 0156-4b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4b · Anglès professional:** Redacta textos breves relacionados amb aspectos cotidianos y/o professionals.
- **CE externs combinats:**
  - **0842-6a · Pentinats i recollits · RA6:** Caracteritza els tipus de perruques i els seus modes d’adaptació.
  - **0844-3a · Cosmètica per a perruqueria · RA3:** Diferencia els tipos de cosmètics que se emplean en un establecimiento de perruqueria.
  - **0849-2f · Anàlisi capil·lar · RA2:** Determina les medidas de protecció per a usuaris i professionals.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4b + 0842-6a + 0844-3a + 0849-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 132. Producte final per al client o portafolis: 0156-4b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4b · Anglès professional:** Redacta textos breves relacionados amb aspectos cotidianos y/o professionals.
- **CE externs combinats:**
  - **0845-7b · Tècniques de tall de cabells · RA7:** Adapta l’estil de tall a l’anàlisi prèvia de les característiques de la persona usuària.
  - **0846-2d · Canvis de forma permanent del cabell · RA2:** Identifica les alteraciones del cuero cabelludo i del cabell.
  - **1664-1f · Digitalització aplicada als sectors productius · RA1:** Compara els modelos anteriores en relación amb su impacto medioambiental i els ODS (Objetivos de Desarrollo Sostenible).
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4b + 0845-7b + 0846-2d + 1664-1f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 34. 0156-4c — Organitza la informació de manera coherente i cohesionada.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 133. Repte pràctic de diagnòstic i decisió: 0156-4c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4c · Anglès professional:** Organitza la informació de manera coherente i cohesionada.
- **CE externs combinats:**
  - **1709-3i · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica el dret fonamental a la vaga, les mesures de conflicte col·lectiu i els òrgans i procediments per a la resolució de conflictes.
  - **0845-7c · Tècniques de tall de cabells · RA7:** Relaciona l’estil de tall proposat amb altres tècniques de perruqueria, com el canvi de color o de forma.
  - **0846-2e · Canvis de forma permanent del cabell · RA2:** Registra els dades más relevantes en la fitxa tècnica.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4c + 1709-3i + 0845-7c + 0846-2e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 134. Taller d’execució guiada: 0156-4c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4c · Anglès professional:** Organitza la informació de manera coherente i cohesionada.
- **CE externs combinats:**
  - **0842-6c · Pentinats i recollits · RA6:** Adapta les perruques correctament.
  - **0844-3c · Cosmètica per a perruqueria · RA3:** Relaciona la composición de un acondicionador amb els efectos que origina en la fibra capil·lar.
  - **0849-3b · Anàlisi capil·lar · RA3:** Identifica els dades que permiten obtener informació útil per a el análisis capil·lar.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4c + 0842-6c + 0844-3c + 0849-3b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 135. Incidència professional i millora: 0156-4c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4c · Anglès professional:** Organitza la informació de manera coherente i cohesionada.
- **CE externs combinats:**
  - **0845-7d · Tècniques de tall de cabells · RA7:** Selecciona cosmètics i eines segons les necessitats.
  - **0846-2f · Canvis de forma permanent del cabell · RA2:** Dissenya procediments de treball personalizados.
  - **1664-2b · Digitalització aplicada als sectors productius · RA2:** Analitza el cambio producido en els sistemas automatizados.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4c + 0845-7d + 0846-2f + 1664-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 136. Producte final per al client o portafolis: 0156-4c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4c · Anglès professional:** Organitza la informació de manera coherente i cohesionada.
- **CE externs combinats:**
  - **0844-3d · Cosmètica per a perruqueria · RA3:** Determina els efectos dels protectores sobre la fibra capil·lar.
  - **0849-3c · Anàlisi capil·lar · RA3:** Elabora la documentación necesaria per a el registro de la informació.
  - **1709-4e · Itinerari personal per a l’ocupabilitat I · RA4:** Valora el concepte d'autoestima en el procés de cerca de feina.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4c + 0844-3d + 0849-3c + 1709-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 35. 0156-4d — Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 137. Repte pràctic de diagnòstic i decisió: 0156-4d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4d · Anglès professional:** Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos.
- **CE externs combinats:**
  - **0842-6e · Pentinats i recollits · RA6:** Fixa les extensions al cabell.
  - **0844-3e · Cosmètica per a perruqueria · RA3:** Estableix les transformaciones que tienen lugar en la fibra capil·lar en els processos de cambio de forma temporal del cabell.
  - **0849-3d · Anàlisi capil·lar · RA3:** Maneja la lupa i la luz de wood per a la observación del estado del cabell i cuero cabelludo.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4d + 0842-6e + 0844-3e + 0849-3d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 138. Taller d’execució guiada: 0156-4d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4d · Anglès professional:** Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos.
- **CE externs combinats:**
  - **0845-7f · Tècniques de tall de cabells · RA7:** Aplica procediments establerts per a cada estil de tall.
  - **0846-3a · Canvis de forma permanent del cabell · RA3:** Condiciona les instalaciones per a que estén en óptimas condiciones de seguretat e higiene.
  - **1664-2d · Digitalització aplicada als sectors productius · RA2:** Descriu la interrelación entre el mundo físico i el virtual.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4d + 0845-7f + 0846-3a + 1664-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 139. Incidència professional i millora: 0156-4d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4d · Anglès professional:** Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos.
- **CE externs combinats:**
  - **0844-3f · Cosmètica per a perruqueria · RA3:** Relaciona la aplicación dels cosmètics específicos del procés de cambio permanente del cabell amb els cambios químicos que tienen lugar en el mismo.
  - **0849-3e · Anàlisi capil·lar · RA3:** Aplica métodos de exploración del cabell.
  - **1709-4g · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica expectatives de futur per a la inserció professional i s’han analitzat competències, interessos i destreses personals.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4d + 0844-3f + 0849-3e + 1709-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 140. Producte final per al client o portafolis: 0156-4d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4d · Anglès professional:** Realitza resúmenes de textos relacionados amb su entorno professional, identificando les ideas principales dels mismos.
- **CE externs combinats:**
  - **0846-3b · Canvis de forma permanent del cabell · RA3:** Aplica les medidas de protecció i seguretat del professional i el usuari.
  - **1664-2e · Digitalització aplicada als sectors productius · RA2:** Relaciona la migración a entornos 4.0 amb la mejora dels resultats de les empresas.
  - **0842-7c · Pentinats i recollits · RA7:** Identifica els útils necessaris per a la conservació del pentinat o del recollit.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4d + 0846-3b + 1664-2e + 0842-7c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 36. 0156-4e — Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 141. Repte pràctic de diagnòstic i decisió: 0156-4e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4e · Anglès professional:** Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico.
- **CE externs combinats:**
  - **0845-7h · Tècniques de tall de cabells · RA7:** Valora el resultat final.
  - **0846-3c · Canvis de forma permanent del cabell · RA3:** Identifica les posturas corporales adequadas per a prevenir accidentes.
  - **1664-2f · Digitalització aplicada als sectors productius · RA2:** Identifica les ventajas per a clients i empresas.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4e + 0845-7h + 0846-3c + 1664-2f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 142. Taller d’execució guiada: 0156-4e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4e · Anglès professional:** Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico.
- **CE externs combinats:**
  - **0844-3h · Cosmètica per a perruqueria · RA3:** Reconeix els cosmètics per a les alteraciones capil·lares que se emplean habitualmente en establecimientos de perruqueria.
  - **0849-3g · Anàlisi capil·lar · RA3:** Realitza la recogida de informació.
  - **1709-4i · Itinerari personal per a l’ocupabilitat I · RA4:** Identifica els itineraris formatius professionals relacionats amb el perfil professional.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4e + 0844-3h + 0849-3g + 1709-4i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 143. Incidència professional i millora: 0156-4e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4e · Anglès professional:** Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico.
- **CE externs combinats:**
  - **0846-3d · Canvis de forma permanent del cabell · RA3:** Caracteritza els útils i eines necessaris per a el procés.
  - **1664-3a · Digitalització aplicada als sectors productius · RA3:** Identifica els diferentes niveles de la cloud /nube.
  - **0842-7e · Pentinats i recollits · RA7:** Justifica els mètodes de conservació i manteniment d’ornaments.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4e + 0846-3d + 1664-3a + 0842-7e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 144. Producte final per al client o portafolis: 0156-4e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4e · Anglès professional:** Emplena documentación específica de su campo professional, aplicando les fórmulas establecidas i el vocabulario específico.
- **CE externs combinats:**
  - **0849-3h · Anàlisi capil·lar · RA3:** Relaciona els dades obtenidos amb su posible derivación a otros professionals.
  - **1709-4j · Itinerari personal per a l’ocupabilitat I · RA4:** Formula objectius professionals i s'han determinat metes personals i professionals per millorar l'ocupabilitat i les condicions d'inserció laboral.
  - **0845-1d · Tècniques de tall de cabells · RA1:** Estableix pautes d’higiene postural correcta durant el tall.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4e + 0849-3h + 1709-4j + 0845-1d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 37. 0156-4f — Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 145. Repte pràctic de diagnòstic i decisió: 0156-4f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4f · Anglès professional:** Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas.
- **CE externs combinats:**
  - **0844-4a · Cosmètica per a perruqueria · RA4:** Identifica els cosmètics per a manicura i pedicura.
  - **0849-4a · Anàlisi capil·lar · RA4:** Caracteritza les fases de un protocolo.
  - **1709-4k · Itinerari personal per a l’ocupabilitat I · RA4:** Traça un pla d’acció per desenvolupar les àrees de millora i potenciar les fortaleses personals amb valor per a l’ocupació.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4f + 0844-4a + 0849-4a + 1709-4k.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 146. Taller d’execució guiada: 0156-4f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4f · Anglès professional:** Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas.
- **CE externs combinats:**
  - **0846-3f · Canvis de forma permanent del cabell · RA3:** Selecciona els moldes en función de les características del cabell i el resultat deseado.
  - **1664-3c · Digitalització aplicada als sectors productius · RA3:** Descriu el concepto de edge computing i su relación amb la cloud/ nube.
  - **0842-1a · Pentinats i recollits · RA1:** Relaciona els tipus d’oval i les siluetes amb el pentinat adequat.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4f + 0846-3f + 1664-3c + 0842-1a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 147. Incidència professional i millora: 0156-4f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4f · Anglès professional:** Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas.
- **CE externs combinats:**
  - **0849-4b · Anàlisi capil·lar · RA4:** Estableix les pautas delaboración de protocolos per a els cuidados capil·lares en descamaciones, cabell seco i frágil.
  - **1709-5a · Itinerari personal per a l’ocupabilitat I · RA5:** Pren consciència de la responsabilitat individual en el desenvolupament professional per tal de valorar l'actitud d'aprenentatge permanent per al desenvolupament de competències pròpies i noves.
  - **0845-1f · Tècniques de tall de cabells · RA1:** Aplica protocols d’higiene i manteniment d’eines i útils.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4f + 0849-4b + 1709-5a + 0845-1f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 148. Producte final per al client o portafolis: 0156-4f

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4f** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4f · Anglès professional:** Emplena un texto dado amb apoyos visuales i claves lingüísticas aportadas.
- **CE externs combinats:**
  - **1664-3d · Digitalització aplicada als sectors productius · RA3:** Defineix els conceptos de fog i mist i sus zonas de aplicación en el conjunto.
  - **0842-1b · Pentinats i recollits · RA1:** Relaciona els tipus de recollit amb l’anàlisi morfològica i capil·lar.
  - **0844-4f · Cosmètica per a perruqueria · RA4:** Estableix la acción de cada cosmètic empleado en les tècniques de barbería, en función de sus principios activos.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4f + 1664-3d + 0842-1b + 0844-4f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 38. 0156-4g — Utilitza les fórmulas de tallsía propias del documento que se va a elaborar.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 149. Repte pràctic de diagnòstic i decisió: 0156-4g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4g · Anglès professional:** Utilitza les fórmulas de tallsía propias del documento que se va a elaborar.
- **CE externs combinats:**
  - **0846-3h · Canvis de forma permanent del cabell · RA3:** Manipula i conservado els productos químicos i cosmètics en condiciones de seguretat e higiene.
  - **1664-3e · Digitalització aplicada als sectors productius · RA3:** Identifica les ventajas que proporciona la utilización de la cloud /nube en els sistemas conectados.
  - **0842-1c · Pentinats i recollits · RA1:** Diferencia les característiques del cabell i la seva relació amb el pentinat.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4g + 0846-3h + 1664-3e + 0842-1c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 150. Taller d’execució guiada: 0156-4g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4g · Anglès professional:** Utilitza les fórmulas de tallsía propias del documento que se va a elaborar.
- **CE externs combinats:**
  - **0849-4d · Anàlisi capil·lar · RA4:** Determina els medios, tècniques i materials necessaris.
  - **1709-5c · Itinerari personal per a l’ocupabilitat I · RA5:** Coneix i utilitzat eines, fonts d'informació, connexions i activitats per configurar un entorn personal d'aprenentatge per a l'ocupabilitat.
  - **0845-2a · Tècniques de tall de cabells · RA2:** Identifica les diferències entre tècnica i estil de tall.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4g + 0849-4d + 1709-5c + 0845-2a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 151. Incidència professional i millora: 0156-4g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4g · Anglès professional:** Utilitza les fórmulas de tallsía propias del documento que se va a elaborar.
- **CE externs combinats:**
  - **1664-4a · Digitalització aplicada als sectors productius · RA4:** Identifica les tecnologías habilitadoras (THD) actuales que definen un sistema digitalizado.
  - **0842-1d · Pentinats i recollits · RA1:** Identifica la repercussió del tipus de tall, de les alteracions, dels estils i d’altres factors en la selecció del pentinat.
  - **0844-4h · Cosmètica per a perruqueria · RA4:** Identifica la cosmética masculina de protecció i de tratamiento.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4g + 1664-4a + 0842-1d + 0844-4h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 152. Producte final per al client o portafolis: 0156-4g

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4g** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4g · Anglès professional:** Utilitza les fórmulas de tallsía propias del documento que se va a elaborar.
- **CE externs combinats:**
  - **1709-5d · Itinerari personal per a l’ocupabilitat I · RA5:** Posa en pràctica la competència digital per configurar un entorn personal d’aprenentatge per a l’ocupabilitat.
  - **0845-2b · Tècniques de tall de cabells · RA2:** Caracteritza les tècniques de tall recte, desfilat, dentat, entresacat i puntejat.
  - **0846-4e · Canvis de forma permanent del cabell · RA4:** Verifica el montaje de bigudíes.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4g + 1709-5d + 0845-2b + 0846-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 39. 0156-4h — Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 153. Repte pràctic de diagnòstic i decisió: 0156-4h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4h · Anglès professional:** Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual.
- **CE externs combinats:**
  - **0849-5a · Anàlisi capil·lar · RA5:** Determina els tipos de maniobras del masaje capil·lar.
  - **1709-5e · Itinerari personal per a l’ocupabilitat I · RA5:** Analitza el concepte d'identitat digital i el seu impacte en l'ocupabilitat.
  - **0845-2c · Tècniques de tall de cabells · RA2:** Determina els útils emprats en cada tècnica de tall.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4h + 0849-5a + 1709-5e + 0845-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 154. Taller d’execució guiada: 0156-4h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4h · Anglès professional:** Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual.
- **CE externs combinats:**
  - **1664-4c · Digitalització aplicada als sectors productius · RA4:** Descriu la contribución de les THD a la mejora de la productividad i la eficiencia dels sistemas productivos o de prestación de servicios.
  - **0842-1f · Pentinats i recollits · RA1:** Estableix les formes i tendències en els recollits.
  - **0844-5b · Cosmètica per a perruqueria · RA5:** Relaciona les alteraciones en la composición dels productos cosmètics amb els cambios que se originan en sus características organolépticas.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4h + 1664-4c + 0842-1f + 0844-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 155. Incidència professional i millora: 0156-4h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4h · Anglès professional:** Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual.
- **CE externs combinats:**
  - **1709-5f · Itinerari personal per a l’ocupabilitat I · RA5:** Justifica el disseny del seu entorn d'aprenentatge basat en la millora l'ocupabilitat.
  - **0845-2d · Tècniques de tall de cabells · RA2:** Estableix les línies de tall adequades per a cada tècnica.
  - **0846-4g · Canvis de forma permanent del cabell · RA4:** Controla el procés durante el tiempo de exposición.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4h + 1709-5f + 0845-2d + 0846-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 156. Producte final per al client o portafolis: 0156-4h

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4h** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4h · Anglès professional:** Escriu correspondencia formal básica en formato físico o digital destinada principalmente a pedir informació, solicitar un servicio o llevar a cabo una reclamación u otra gestión sencilla, siempre atendiendo a les convenciones de la tipología textual.
- **CE externs combinats:**
  - **0842-1g · Pentinats i recollits · RA1:** Aplica mètodes per determinar tendències en pentinats i recollits a partir de fonts documentals.
  - **0844-5c · Cosmètica per a perruqueria · RA5:** Identifica les condiciones óptimas de almacenamiento per a garantizar la correcta conservación dels productos cosmètics.
  - **0849-5f · Anàlisi capil·lar · RA5:** Realitza la desinfecció y/o esterilització dels materials i aparells.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4h + 0842-1g + 0844-5c + 0849-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 40. 0156-4i — Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional.

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 157. Repte pràctic de diagnòstic i decisió: 0156-4i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4i · Anglès professional:** Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional.
- **CE externs combinats:**
  - **1664-4e · Digitalització aplicada als sectors productius · RA4:** Relaciona la implantación de les tecnologías habilitadoras (sensórica, tratamiento de dades, automatización i comunicaciones, entre otras) amb la reducción de costes i la mejora de la competitividad.
  - **0842-1h · Pentinats i recollits · RA1:** Identifica mètodes d’anàlisi de necessitats i demandes de les persones usuàries.
  - **0844-5d · Cosmètica per a perruqueria · RA5:** Especifica les pautas correctas de manipulación dels productos cosmètics per a garantizar unas condiciones higiénico-sanitarias idóneas de aplicación.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4i + 1664-4e + 0842-1h + 0844-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 158. Taller d’execució guiada: 0156-4i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4i · Anglès professional:** Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional.
- **CE externs combinats:**
  - **1709-5h · Itinerari personal per a l’ocupabilitat I · RA5:** Aplica les eines d'aprenentatge autònom per al desenvolupament personal i professional.
  - **0845-2f · Tècniques de tall de cabells · RA2:** Determina les zones d’aplicació de cada tècnica de tall.
  - **0846-4i · Canvis de forma permanent del cabell · RA4:** Realitza els ajustes necessaris en el procés.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4i + 1709-5h + 0845-2f + 0846-4i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 159. Incidència professional i millora: 0156-4i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4i · Anglès professional:** Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional.
- **CE externs combinats:**
  - **0842-1i · Pentinats i recollits · RA1:** Dissenya propostes per a processos de pentinat i recollit.
  - **0844-5e · Cosmètica per a perruqueria · RA5:** Analitza les consecuencias de una incorrecta manipulación dels productos cosmètics.
  - **0849-5h · Anàlisi capil·lar · RA5:** Justifica la valoración del resultat obtenido como factor de calidad del procés.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4i + 0842-1i + 0844-5e + 0849-5h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 160. Producte final per al client o portafolis: 0156-4i

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4i** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4i · Anglès professional:** Pren notas, i missatges, amb informació sencilla sobre aspectos propios de su labor professional.
- **CE externs combinats:**
  - **0845-2g · Tècniques de tall de cabells · RA2:** Selecciona procediments per realitzar tècniques de desfilat, dentat, entresacat i puntejat.
  - **0846-4j · Canvis de forma permanent del cabell · RA4:** Aplica les normas de prevenció, seguretat i protecció ambiental estipuladas, durante el procés de treball.
  - **1664-5b · Digitalització aplicada als sectors productius · RA5:** Identifica les etapas susceptibles de ser digitalizadas.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4i + 0845-2g + 0846-4j + 1664-5b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 41. 0156-4j — Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros).

**RA del mòdul eix:** 0156-RA4. Redacció de textos senzills en llengua anglesa amb finalitat professional.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 161. Repte pràctic de diagnòstic i decisió: 0156-4j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4j · Anglès professional:** Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros).
- **CE externs combinats:**
  - **1709-1a · Itinerari personal per a l’ocupabilitat I · RA1:** Analitza les principals oportunitats d'ocupació i d'inserció laboral al sector professional, s’han identificat les possibilitats d'ocupació i analitzat els requeriments actuals per al perfil professional.
  - **0845-2h · Tècniques de tall de cabells · RA2:** Relaciona els paràmetres que defineixen cada tècnica amb els efectes aconseguits.
  - **0846-5a · Canvis de forma permanent del cabell · RA5:** Estableix parámetros per a la realización de desrizados i alisados del cabell.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-4j + 1709-1a + 0845-2h + 0846-5a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 162. Taller d’execució guiada: 0156-4j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4j · Anglès professional:** Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros).
- **CE externs combinats:**
  - **0842-2b · Pentinats i recollits · RA2:** Caracteritza els útils i les eines emprats.
  - **0844-6a · Cosmètica per a perruqueria · RA6:** Identifica les líneas comerciales de cosmètics per a perruqueria.
  - **0849-6b · Anàlisi capil·lar · RA6:** Valora la aplicación de normas deontológicas en el desarrollo professional.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-4j + 0842-2b + 0844-6a + 0849-6b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 163. Incidència professional i millora: 0156-4j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4j · Anglès professional:** Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros).
- **CE externs combinats:**
  - **0845-3a · Tècniques de tall de cabells · RA3:** Identifica les característiques i alteracions del cabell que influeixen en el tall.
  - **0846-5b · Canvis de forma permanent del cabell · RA5:** Caracteritza la tècnica de aplicación.
  - **1664-5d · Digitalització aplicada als sectors productius · RA5:** Estableix la conexión de les etapas digitalizadas amb el resto del sistema.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-4j + 0845-3a + 0846-5b + 1664-5d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 164. Producte final per al client o portafolis: 0156-4j

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-4j** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-4j · Anglès professional:** Sol·licita de forma escrita, informació referente a aspectos relacionados amb su campo professional (página web i correo electrónico, entre otros).
- **CE externs combinats:**
  - **0844-6b · Cosmètica per a perruqueria · RA6:** Estableix les diferencias entre els cosmètics de venta al público i els de uso professional.
  - **0849-6c · Anàlisi capil·lar · RA6:** Determina els deures i obligaciones del professional.
  - **1709-2c · Itinerari personal per a l’ocupabilitat I · RA2:** Determina l'avaluació de riscos a l'empresa o organisme equiparat i s’han definit les tècniques de prevenció i de protecció que cal aplicar per evitar els danys a l'origen i minimitzar-ne les conseqüències.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-4j + 0844-6b + 0849-6c + 1709-2c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 42. 0156-5a — Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera.

**RA del mòdul eix:** 0156-RA5. Actituds i comportaments professionals en situacions de comunicació intercultural.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 165. Repte pràctic de diagnòstic i decisió: 0156-5a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5a · Anglès professional:** Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0842-2d · Pentinats i recollits · RA2:** Estableix pautes de manteniment d’aparells, útils i complements.
  - **0844-6c · Cosmètica per a perruqueria · RA6:** Especifica els establecimientos de venta de cosmètics per a perruqueria.
  - **0849-6d · Anàlisi capil·lar · RA6:** Valora la importancia i repercusión del treball honesto.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-5a + 0842-2d + 0844-6c + 0849-6d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 166. Taller d’execució guiada: 0156-5a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5a · Anglès professional:** Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0845-3c · Tècniques de tall de cabells · RA3:** Relaciona les proporcions facials i corporals amb el canvi de longitud del cabell.
  - **0846-5d · Canvis de forma permanent del cabell · RA5:** Aplica els líquidos reductores per a el alisado permanente.
  - **1664-5f · Digitalització aplicada als sectors productius · RA5:** Elabora un informe de viabilidad i de les mejoras introducidas.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-5a + 0845-3c + 0846-5d + 1664-5f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 167. Incidència professional i millora: 0156-5a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5a · Anglès professional:** Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0844-6d · Cosmètica per a perruqueria · RA6:** Realitza fitxas informativas sobre els efectos i la aplicación de cosmètics.
  - **0849-6e · Anàlisi capil·lar · RA6:** Justifica la necesidad del secreto professional en la profesión.
  - **1709-2e · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els drets i deures principals en matèria de prevenció de riscos laborals.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-5a + 0844-6d + 0849-6e + 1709-2e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 168. Producte final per al client o portafolis: 0156-5a

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5a** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5a · Anglès professional:** Defineix els rasgos más significativos de les costumbres i usos de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0846-5e · Canvis de forma permanent del cabell · RA5:** Controla el procés durante el tiempo de exposición.
  - **1664-5g · Digitalització aplicada als sectors productius · RA5:** Analitza la mejora en la producción i gestión de residuos, entre otras.
  - **0842-3a · Pentinats i recollits · RA3:** Identifica els requisits del rentacaps i de la butaca.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-5a + 0846-5e + 1664-5g + 0842-3a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 43. 0156-5b — Descriu els protocolos i normas de relación social propios del país.

**RA del mòdul eix:** 0156-RA5. Actituds i comportaments professionals en situacions de comunicació intercultural.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 169. Repte pràctic de diagnòstic i decisió: 0156-5b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5b · Anglès professional:** Descriu els protocolos i normas de relación social propios del país.
- **CE externs combinats:**
  - **0845-3e · Tècniques de tall de cabells · RA3:** Identifica els elements d’un esbós de proposta de tall.
  - **0846-5f · Canvis de forma permanent del cabell · RA5:** Aplica el neutralizante siguiendo el procediment establecido.
  - **1664-5h · Digitalització aplicada als sectors productius · RA5:** Elabora un documento amb la secuencia del plan de transformación i els recursos empleados.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-5b + 0845-3e + 0846-5f + 1664-5h.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 170. Taller d’execució guiada: 0156-5b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5b · Anglès professional:** Descriu els protocolos i normas de relación social propios del país.
- **CE externs combinats:**
  - **0844-6f · Cosmètica per a perruqueria · RA6:** Determina la importancia de mantener una constante actualización en productos de innovación en perruqueria.
  - **0849-6g · Anàlisi capil·lar · RA6:** Valora la repercusión de la ley de protecció de dades en el ejercicio professional de la perruqueria.
  - **1709-2g · Itinerari personal per a l’ocupabilitat I · RA2:** Valora la importància de l'existència d'un pla preventiu a l'empresa o organisme equiparat que inclogui la seqüenciació d'actuacions que cal realitzar en cas d'emergència i s’ha reflexionat sobre el seu contingut.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-5b + 0844-6f + 0849-6g + 1709-2g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 171. Incidència professional i millora: 0156-5b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5b · Anglès professional:** Descriu els protocolos i normas de relación social propios del país.
- **CE externs combinats:**
  - **0846-5g · Canvis de forma permanent del cabell · RA5:** Realitza els ajustes necessaris en el procés.
  - **1664-1a · Digitalització aplicada als sectors productius · RA1:** Identifica les etapas «típicas» dels modelos basados en EL i modelos basados en EC.
  - **0842-3c · Pentinats i recollits · RA3:** Segueix pautes de manipulació dels cosmètics.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-5b + 0846-5g + 1664-1a + 0842-3c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 172. Producte final per al client o portafolis: 0156-5b

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5b** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5b · Anglès professional:** Descriu els protocolos i normas de relación social propios del país.
- **CE externs combinats:**
  - **0849-1a · Anàlisi capil·lar · RA1:** Identifica les características i elementos que componen el relieve cutani.
  - **1709-2h · Itinerari personal per a l’ocupabilitat I · RA2:** Determina els requisits i les condicions per a la vigilància de la salut de la persona treballadora i la seva importància com a mesura de prevenció.
  - **0845-4c · Tècniques de tall de cabells · RA4:** Efectua les tècniques prèvies de condicionament del cabell.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-5b + 0849-1a + 1709-2h + 0845-4c.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 44. 0156-5c — Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera.

**RA del mòdul eix:** 0156-RA5. Actituds i comportaments professionals en situacions de comunicació intercultural.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 173. Repte pràctic de diagnòstic i decisió: 0156-5c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5c · Anglès professional:** Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0844-1a · Cosmètica per a perruqueria · RA1:** Identifica les características del producto cosmètic segons la reglamentación técnico-sanitaria.
  - **0849-1b · Anàlisi capil·lar · RA1:** Caracteritza la estructura de la pell i sus glándulas.
  - **1709-2i · Itinerari personal per a l’ocupabilitat I · RA2:** Identifica les tècniques bàsiques de primers auxilis que han de ser aplicades al lloc de l'accident en cas de diferents tipus de danys i la composició i ús de la farmaciola.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-5c + 0844-1a + 0849-1b + 1709-2i.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 174. Taller d’execució guiada: 0156-5c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5c · Anglès professional:** Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0846-5i · Canvis de forma permanent del cabell · RA5:** Determina els cuidados posteriores al desrizado.
  - **1664-1c · Digitalització aplicada als sectors productius · RA1:** Valora la importancia del reciclaje en els modelos económicos.
  - **0842-3e · Pentinats i recollits · RA3:** Estableix les fases i pautes d’aplicació.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-5c + 0846-5i + 1664-1c + 0842-3e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 175. Incidència professional i millora: 0156-5c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5c · Anglès professional:** Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **0849-1c · Anàlisi capil·lar · RA1:** Especifica els tipos de pelo, estableciéndose sus características i criteris de clasificación.
  - **1709-3a · Itinerari personal per a l’ocupabilitat I · RA3:** Analitza els drets i les obligacions derivats de la relació laboral, així com les condicions de treball pactades en un conveni col·lectiu aplicable en el sector professional relacionat amb el títol.
  - **0845-4e · Tècniques de tall de cabells · RA4:** Estableix paràmetres per a la realització del tall.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-5c + 0849-1c + 1709-3a + 0845-4e.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 176. Producte final per al client o portafolis: 0156-5c

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5c** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5c · Anglès professional:** Identifica els valores i creencias propios de la comunidad donde s’habla la lengua extranjera.
- **CE externs combinats:**
  - **1664-1d · Digitalització aplicada als sectors productius · RA1:** Identifica processos reales basados en EL.
  - **0842-3f · Pentinats i recollits · RA3:** Realitza maniobres de massatge per a la neteja del cabell i del cuir cabellut.
  - **0844-1f · Cosmètica per a perruqueria · RA1:** Valora la importancia de la parte externa del cosmètic como medio de informació al consumidor.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-5c + 1664-1d + 0842-3f + 0844-1f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 45. 0156-5d — Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto.

**RA del mòdul eix:** 0156-RA5. Actituds i comportaments professionals en situacions de comunicació intercultural.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 177. Repte pràctic de diagnòstic i decisió: 0156-5d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5d · Anglès professional:** Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto.
- **CE externs combinats:**
  - **0846-6a · Canvis de forma permanent del cabell · RA6:** Determina els factores que afectan al resultat.
  - **1664-1e · Digitalització aplicada als sectors productius · RA1:** Identifica processos reales basados en EC.
  - **0842-3g · Pentinats i recollits · RA3:** Selecciona cosmètics en funció de les característiques del cabell.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-5d + 0846-6a + 1664-1e + 0842-3g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 178. Taller d’execució guiada: 0156-5d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5d · Anglès professional:** Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto.
- **CE externs combinats:**
  - **0849-1e · Anàlisi capil·lar · RA1:** Reconeix les características i componentes del cabell.
  - **1709-3c · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica les característiques definitòries dels nous entorns d'organització del treball i els drets que comporta, així com les mesures vigents per a la conciliació de la vida laboral i familiar.
  - **0845-4g · Tècniques de tall de cabells · RA4:** Seqüencia el tall en l’ordre establert.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-5d + 0849-1e + 1709-3c + 0845-4g.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 179. Incidència professional i millora: 0156-5d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5d · Anglès professional:** Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto.
- **CE externs combinats:**
  - **1664-1f · Digitalització aplicada als sectors productius · RA1:** Compara els modelos anteriores en relación amb su impacto medioambiental i els ODS (Objetivos de Desarrollo Sostenible).
  - **0842-3h · Pentinats i recollits · RA3:** Especifica el tipus de condicionament capil·lar en funció del servei posterior.
  - **0844-2b · Cosmètica per a perruqueria · RA2:** Realitza les operaciones básicas per a elaborar cosmètics: medidas de peso i de volumen.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-5d + 1664-1f + 0842-3h + 0844-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 180. Producte final per al client o portafolis: 0156-5d

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5d** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5d · Anglès professional:** Identifica els aspectos socio-professionals propios del sector, en cualquier tipo de texto.
- **CE externs combinats:**
  - **1709-3d · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els diferents components del rebut de salari.
  - **0845-4h · Tècniques de tall de cabells · RA4:** Aplica procediments establerts en la realització del tall amb tisora.
  - **0846-6f · Canvis de forma permanent del cabell · RA6:** Segueix el protocolo de actuación en casos de irritaciones i alergias.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-5d + 1709-3d + 0845-4h + 0846-6f.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

### CE 46. 0156-5e — Aplica els protocolos i normas de relación social propios del país de la lengua extranjera.

**RA del mòdul eix:** 0156-RA5. Actituds i comportaments professionals en situacions de comunicació intercultural.
**Focus pràctic:** comunicació professional en anglès en situacions reals de perruqueria.

#### Activitat 181. Repte pràctic de diagnòstic i decisió: 0156-5e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5e · Anglès professional:** Aplica els protocolos i normas de relación social propios del país de la lengua extranjera.
- **CE externs combinats:**
  - **0849-1g · Anàlisi capil·lar · RA1:** Relaciona les características de una pell normal amb sus posibles variaciones i su repercusión capil·lar.
  - **1709-3e · Itinerari personal per a l’ocupabilitat I · RA3:** Identifica els recursos laborals existents en les diferents vicissituds que es poden generar en la relació laboral.
  - **0845-5a · Tècniques de tall de cabells · RA5:** Estableix diferències entre el tall amb navalla i el tall amb tisora.
- **Metodologia activa:** Aprenentatge basat en reptes.
- **Desenvolupament pràctic:** L’equip rep una fitxa de client, una fotografia o un maniquí amb una necessitat concreta. Ha d’observar, preguntar, detectar condicionants i decidir com actuar connectant el CE propi amb els CE externs. La decisió es justifica abans de tocar el material. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Fitxa de diagnòstic i decisió tècnica justificada.
- **Aprenentatges i criteris avaluables:** 0156-5e + 0849-1g + 1709-3e + 0845-5a.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Fitxa de client en lectura fàcil, pictogrames de passos, preguntes model i possibilitat de respondre primer oralment.

#### Activitat 182. Taller d’execució guiada: 0156-5e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5e · Anglès professional:** Aplica els protocolos i normas de relación social propios del país de la lengua extranjera.
- **CE externs combinats:**
  - **1664-2b · Digitalització aplicada als sectors productius · RA2:** Analitza el cambio producido en els sistemas automatizados.
  - **0842-4a · Pentinats i recollits · RA4:** Determina les operacions prèvies i les particions del cabell en funció del pentinat.
  - **0844-2d · Cosmètica per a perruqueria · RA2:** Estableix la diferencia entre composición cuantitativa i cualitativa.
- **Metodologia activa:** Aprenentatge pràctic per estacions.
- **Desenvolupament pràctic:** L’alumnat prepara una estació de treball amb material real o simulat, executa una part del procediment i registra quins passos responen a cada criteri. Un company usa una llista de control per verificar tècnica, ordre, higiene i comunicació. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Llista de control emplenada, fotografia de l’estació i registre de passos.
- **Aprenentatges i criteris avaluables:** 0156-5e + 1664-2b + 0842-4a + 0844-2d.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Llista de control visual, demostració prèvia, rols definits i material etiquetat per colors.

#### Activitat 183. Incidència professional i millora: 0156-5e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5e · Anglès professional:** Aplica els protocolos i normas de relación social propios del país de la lengua extranjera.
- **CE externs combinats:**
  - **1709-3f · Itinerari personal per a l’ocupabilitat I · RA3:** Valora el paper de la Seguretat Social com a pilar essencial per millorar la qualitat de vida dels ciutadans.
  - **0845-5b · Tècniques de tall de cabells · RA5:** Estableix pautes per al maneig de la navalla.
  - **0846-1b · Canvis de forma permanent del cabell · RA1:** Compara els procediments de ondulación permanente a lo largo de la historia amb els actuales.
- **Metodologia activa:** Aprenentatge basat en problemes.
- **Desenvolupament pràctic:** Es lliura una incidència realista: producte inadequat, manca d’informació, eina mal seleccionada, risc d’higiene, error de comunicació o resultat poc coherent. L’equip analitza causes, proposa dues solucions, en tria una i la prova o la simula. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Informe breu d’incidència, solució triada i evidència de correcció.
- **Aprenentatges i criteris avaluables:** 0156-5e + 1709-3f + 0845-5b + 0846-1b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Targetes d’incidència amb tres nivells de dificultat, frases d’inici i opció d’esquema en lloc de text llarg.

#### Activitat 184. Producte final per al client o portafolis: 0156-5e

- **Context / idea motivadora:** L’alumnat treballa el CE **0156-5e** en una situació de saló relacionada amb **comunicació professional en anglès en situacions reals de perruqueria**. L’activitat es combina amb altres mòduls perquè la decisió no sigui aïllada, sinó professional i intermodular.
- **CE propi avaluat:** **0156-5e · Anglès professional:** Aplica els protocolos i normas de relación social propios del país de la lengua extranjera.
- **CE externs combinats:**
  - **0842-4b · Pentinats i recollits · RA4:** Estableix les característiques de les diferents tècniques de canvi de forma.
  - **0844-2e · Cosmètica per a perruqueria · RA2:** Caracteritza les diferentes formas cosméticas.
  - **0849-2b · Anàlisi capil·lar · RA2:** Classifica els equips complementarios per a els cuidados estéticos capil·lares.
- **Metodologia activa:** Aprenentatge per projectes i portafolis.
- **Desenvolupament pràctic:** L’alumnat transforma el que ha treballat en un producte professional: consell al client, protocol visual, miniguia, vídeo curt, fitxa tècnica, entrada de portafolis o presentació. Ha d’explicar quins CE s’han treballat i quina evidència demostra l’aprenentatge. La tasca es realitza amb material real o simulat de l’aula-taller: maniquí, fitxes de client, útils, cosmètics, imatges, documents de saló o eines digitals. El docent observa el procés i no només el producte final.
- **Producte / evidència:** Producte professional final i defensa breu davant el grup.
- **Aprenentatges i criteris avaluables:** 0156-5e + 0842-4b + 0844-2e + 0849-2b.
- **Avaluació:** rúbrica breu amb quatre indicadors: aplicació tècnica del CE propi, connexió amb els CE externs, seguretat/higiene/ordre i qualitat de l’evidència lliurada.
- **Ajudes / pautes DUA:** Plantilla de producte final, banc d’imatges, opció de format digital o paper i revisió per parelles abans de lliurar.

---

## Comprovació del document

- **Mòdul eix:** 0156. Anglès professional.
- **CE coberts del mòdul:** 46.
- **Activitats desenvolupades:** 184.
- **Activitats per CE:** 4.
- **Tots els CE tenen almenys una activitat combinada amb un altre mòdul:** sí.
- **Mòduls externs utilitzats:** 0842 (79 aparicions), 0844 (78 aparicions), 0845 (79 aparicions), 0846 (78 aparicions), 0849 (79 aparicions), 1664 (79 aparicions), 1709 (80 aparicions).
- **Combinacions diferents de CE:** 184.